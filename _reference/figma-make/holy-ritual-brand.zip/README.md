
  # holy-ritual-brand

  This is a code bundle for holy-ritual-brand. The original project is available at https://www.figma.com/design/qpSDIsKZvNRaDCEEqV704U/holy-ritual-brand.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  