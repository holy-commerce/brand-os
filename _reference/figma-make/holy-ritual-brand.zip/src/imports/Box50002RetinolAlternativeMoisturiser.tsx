export default function Box50002RetinolAlternativeMoisturiser() {
  return <div className="bg-[darkgrey] size-full" data-name="BOX50-002-Retinol Alternative Moisturiser" />;
}