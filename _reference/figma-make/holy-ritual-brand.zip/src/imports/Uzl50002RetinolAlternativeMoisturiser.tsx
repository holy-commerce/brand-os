export default function Uzl50002RetinolAlternativeMoisturiser() {
  return <div className="bg-[darkgrey] size-full" data-name="UZL50-002-Retinol Alternative Moisturiser" />;
}