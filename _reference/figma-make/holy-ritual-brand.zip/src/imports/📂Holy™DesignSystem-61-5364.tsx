import svgPaths from "./svg-sg8020fpd2";

function Icon() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p157dd580} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p24b0a880} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M2.66667 12H29.3333" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[38.398px] relative shrink-0 w-[586.672px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[38.398px] relative w-[586.672px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[38.4px] left-0 not-italic text-[#1a1a1a] text-[32px] text-nowrap top-[-0.5px] whitespace-pre">HØLY™ Logo System — Embossed Variants</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[12px] h-[38.398px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon />
      <Heading />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[76.805px] opacity-70 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[25.6px] left-0 not-italic text-[#1a1a1a] text-[16px] top-[-1px] w-[840px]">Complete embossed logo library across all brand colors with blind emboss (light backgrounds) and foil emboss (dark backgrounds) treatments. Includes responsive, stacked, and monospaced variants for maximum flexibility across digital and print applications.</p>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_61_3810)" id="Icon" opacity="0.7">
          <path d={svgPaths.p15ab3e60} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M13.3333 1.33333V4" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M14.6667 2.66667H12" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p22966600} id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_61_3810">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[274.266px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[19.5px] relative w-[274.266px]">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[19.5px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-px tracking-[0.65px] uppercase whitespace-pre">Blind Emboss (Light Backgrounds)</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[8px] h-[19.5px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon1 />
      <Paragraph1 />
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[67.195px] opacity-70 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.4px] left-0 not-italic text-[#1a1a1a] text-[14px] top-[0.5px] w-[339px]">Soft drop shadow + inner blur for subtle raised impression. Used on Ivory, Limestone Oat, Veil Clay backgrounds.</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="[grid-area:1_/_1] bg-[#f9f6f0] h-[150.695px] relative rounded-[20px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[20px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[12px] h-[150.695px] items-start pb-[2px] pt-[26px] px-[26px] relative w-full">
          <Container1 />
          <Paragraph2 />
        </div>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_61_3824)" id="Icon" opacity="0.9">
          <path d={svgPaths.p15ab3e60} id="Vector" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M13.3333 1.33333V4" id="Vector_2" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M14.6667 2.66667H12" id="Vector_3" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p22966600} id="Vector_4" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_61_3824">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[259.648px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[19.5px] relative w-[259.648px]">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[19.5px] left-0 not-italic text-[#f9f6f0] text-[13px] text-nowrap top-px tracking-[0.65px] uppercase whitespace-pre">Foil Emboss (Dark Backgrounds)</p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex gap-[8px] h-[19.5px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon2 />
      <Paragraph3 />
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[67.195px] opacity-80 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.4px] left-0 not-italic text-[#f9f6f0] text-[14px] top-[0.5px] w-[348px]">Brushed bronze glow effect with halo. Gradient base (#9C887A) for metallic foil impression on dark surfaces.</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="[grid-area:1_/_2] bg-[#1a1a1a] h-[150.695px] relative rounded-[20px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#8c8981] border-solid inset-0 pointer-events-none rounded-[20px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[12px] h-[150.695px] items-start pb-[2px] pt-[26px] px-[26px] relative w-full">
          <Container3 />
          <Paragraph4 />
        </div>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="gap-[24px] grid grid-cols-[repeat(2,_minmax(0px,_1fr))] grid-rows-[repeat(1,_minmax(0px,_1fr))] h-[150.695px] relative shrink-0 w-full" data-name="Container">
      <Container2 />
      <Container4 />
    </div>
  );
}

function Container6() {
  return (
    <div className="bg-white h-[369.898px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[12px] h-[369.898px] items-start pb-[2px] pt-[34px] px-[34px] relative w-full">
          <Container />
          <Paragraph />
          <Container5 />
        </div>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p3eebfc00} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M20 2V6" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M22 4H18" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p352890c0} id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[33.602px] relative shrink-0 w-[325.875px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[33.602px] relative w-[325.875px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[33.6px] left-0 not-italic text-[#1a1a1a] text-[28px] text-nowrap top-[-0.5px] whitespace-pre">Emboss / Light Backgrounds</p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex gap-[12px] h-[33.602px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon3 />
      <Heading1 />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[22.398px] opacity-70 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.4px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-[0.5px] whitespace-pre">Blind emboss treatment on light neutral backgrounds — Ivory Cream, Limestone Oat, Veil Clay</p>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[64px] items-start left-[34px] top-[34px] w-[859px]" data-name="Container">
      <Container7 />
      <Paragraph5 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#1a1a1a] text-[16px] text-nowrap top-[-1px] whitespace-pre">On Ivory Cream (#F9F6F0)</p>
    </div>
  );
}

function HolyWordmark() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="bg-[#f9f6f0] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark />
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.24px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Void Black</p>
    </div>
  );
}

function LogoShowcase() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container9 />
      <Paragraph6 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[120px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[18px] opacity-80 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-[0.5px] tracking-[1.8px] uppercase whitespace-pre">Ritual Care for Body Modification</p>
    </div>
  );
}

function HolyWordmarkTagline() {
  return (
    <div className="h-[146px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmarkTagline">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-[146px] items-start relative w-[359.734px]">
        <Heading3 />
        <Paragraph7 />
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="bg-[#f9f6f0] h-[242px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[242px] items-center justify-center pl-[0.008px] pr-0 py-0 relative w-full">
          <HolyWordmarkTagline />
        </div>
      </div>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.61px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark + Tagline / Void Black</p>
    </div>
  );
}

function LogoShowcase1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container10 />
      <Paragraph8 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[378.93px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[378.93px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#5e6458] text-[120px] text-nowrap top-0 tracking-[14.4px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="bg-[#5e6458] h-px opacity-30 relative shrink-0 w-[303.141px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-px w-[303.141px]" />
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#5e6458] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyStackedLogo() {
  return (
    <div className="h-[163px] relative shrink-0 w-[378.93px]" data-name="HOLYStackedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[12px] h-[163px] items-center relative w-[378.93px]">
        <Heading4 />
        <Container11 />
        <Paragraph9 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="bg-[#f9f6f0] content-stretch flex h-[259px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyStackedLogo />
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.3px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Stacked / Relic Green</p>
    </div>
  );
}

function LogoShowcase2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[588.66px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container12 />
      <Paragraph10 />
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[285px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase />
      <LogoShowcase1 />
      <LogoShowcase2 />
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[333px] items-start left-[34px] top-[130px] w-[859px]" data-name="Container">
      <Heading2 />
      <Container13 />
    </div>
  );
}

function Heading5() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#1a1a1a] text-[16px] text-nowrap top-[-1px] whitespace-pre">On Limestone Oat (#D7D0C5)</p>
    </div>
  );
}

function Heading6() {
  return (
    <div className="basis-0 grow h-[120px] min-h-px min-w-px relative shrink-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-full">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="bg-[#1a1a1a] h-[84px] opacity-30 relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[84px] w-px" />
    </div>
  );
}

function Paragraph11() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyHorizontalLogo() {
  return (
    <div className="h-[120px] relative shrink-0 w-[486.703px]" data-name="HOLYHorizontalLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex gap-[16px] h-[120px] items-center relative w-[486.703px]">
        <Heading6 />
        <Container15 />
        <Paragraph11 />
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="bg-[#d7d0c5] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyHorizontalLogo />
    </div>
  );
}

function Paragraph12() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.25px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Horizontal / Void Black</p>
    </div>
  );
}

function LogoShowcase3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[602px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container16 />
      <Paragraph12 />
    </div>
  );
}

function HolyWordmark1() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#5e6458] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="bg-[#d7d0c5] h-[216px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[216px] items-center justify-center pl-[0.008px] pr-0 py-0 relative w-full">
          <HolyWordmark1 />
        </div>
      </div>
    </div>
  );
}

function Paragraph13() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.47px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Relic Green</p>
    </div>
  );
}

function LogoShowcase4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[602px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container17 />
      <Paragraph13 />
    </div>
  );
}

function HolyMonospacedLogo() {
  return (
    <div className="h-[480px] relative shrink-0 w-[174.336px]" data-name="HOLYMonospacedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[480px] relative w-[174.336px]">
        <p className="absolute font-['Menlo:Bold',sans-serif] leading-[120px] left-0 not-italic text-[#9c887a] text-[120px] top-0 tracking-[24px] uppercase w-[97px]">H Ø L Y</p>
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="bg-[#d7d0c5] content-stretch flex h-[576px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyMonospacedLogo />
    </div>
  );
}

function Paragraph14() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.37px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Monospaced / Smoky Umber</p>
    </div>
  );
}

function LogoShowcase5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[602px] items-start left-[588.66px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container18 />
      <Paragraph14 />
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[602px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase3 />
      <LogoShowcase4 />
      <LogoShowcase5 />
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[650px] items-start left-[34px] top-[511px] w-[859px]" data-name="Container">
      <Heading5 />
      <Container19 />
    </div>
  );
}

function Heading7() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#1a1a1a] text-[16px] text-nowrap top-[-1px] whitespace-pre">On Veil Clay (#D9C4BB)</p>
    </div>
  );
}

function HolyWordmark2() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="bg-[#d9c4bb] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark2 />
    </div>
  );
}

function Paragraph15() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.24px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Void Black</p>
    </div>
  );
}

function LogoShowcase6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container21 />
      <Paragraph15 />
    </div>
  );
}

function Heading8() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[378.93px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[378.93px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#5e6458] text-[120px] text-nowrap top-0 tracking-[14.4px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="bg-[#5e6458] h-px opacity-30 relative shrink-0 w-[303.141px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-px w-[303.141px]" />
    </div>
  );
}

function Paragraph16() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#5e6458] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyStackedLogo1() {
  return (
    <div className="h-[163px] relative shrink-0 w-[378.93px]" data-name="HOLYStackedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[12px] h-[163px] items-center relative w-[378.93px]">
        <Heading8 />
        <Container22 />
        <Paragraph16 />
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="bg-[#d9c4bb] content-stretch flex h-[259px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyStackedLogo1 />
    </div>
  );
}

function Paragraph17() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.3px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Stacked / Relic Green</p>
    </div>
  );
}

function LogoShowcase7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container23 />
      <Paragraph17 />
    </div>
  );
}

function Heading9() {
  return (
    <div className="basis-0 grow h-[120px] min-h-px min-w-px relative shrink-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-full">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#9c887a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="bg-[#9c887a] h-[84px] opacity-30 relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[84px] w-px" />
    </div>
  );
}

function Paragraph18() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#9c887a] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyHorizontalLogo1() {
  return (
    <div className="h-[120px] relative shrink-0 w-[486.703px]" data-name="HOLYHorizontalLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex gap-[16px] h-[120px] items-center relative w-[486.703px]">
        <Heading9 />
        <Container24 />
        <Paragraph18 />
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="bg-[#d9c4bb] h-[216px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[216px] items-center justify-center pl-[0.008px] pr-0 py-0 relative w-full">
          <HolyHorizontalLogo1 />
        </div>
      </div>
    </div>
  );
}

function Paragraph19() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.21px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Horizontal / Smoky Umber</p>
    </div>
  );
}

function LogoShowcase8() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[588.66px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container25 />
      <Paragraph19 />
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[285px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase6 />
      <LogoShowcase7 />
      <LogoShowcase8 />
    </div>
  );
}

function Container27() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[333px] items-start left-[34px] top-[1209px] w-[859px]" data-name="Container">
      <Heading7 />
      <Container26 />
    </div>
  );
}

function Container28() {
  return (
    <div className="bg-white h-[1576px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container8 />
      <Container14 />
      <Container20 />
      <Container27 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p3eebfc00} id="Vector" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M20 2V6" id="Vector_2" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M22 4H18" id="Vector_3" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p352890c0} id="Vector_4" stroke="var(--stroke-0, #F9F6F0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Heading10() {
  return (
    <div className="h-[33.602px] relative shrink-0 w-[321.18px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[33.602px] relative w-[321.18px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[33.6px] left-0 not-italic text-[#f9f6f0] text-[28px] text-nowrap top-[-0.5px] whitespace-pre">Emboss / Dark Backgrounds</p>
      </div>
    </div>
  );
}

function Container29() {
  return (
    <div className="content-stretch flex gap-[12px] h-[33.602px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon4 />
      <Heading10 />
    </div>
  );
}

function Paragraph20() {
  return (
    <div className="h-[22.398px] opacity-70 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.4px] left-0 not-italic text-[#f9f6f0] text-[14px] text-nowrap top-[0.5px] whitespace-pre">Foil emboss treatment with bronze glow on dark surfaces — Void Black, Relic Green, Fogstone Blue</p>
    </div>
  );
}

function Container30() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[64px] items-start left-[34px] top-[34px] w-[859px]" data-name="Container">
      <Container29 />
      <Paragraph20 />
    </div>
  );
}

function Heading11() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#f9f6f0] text-[16px] text-nowrap top-[-1px] whitespace-pre">On Void Black (#1A1A1A)</p>
    </div>
  );
}

function HolyWordmark3() {
  return (
    <div className="h-[120px] relative shadow-[0px_0px_48px_0px_rgba(156,136,122,0.4),0px_2px_16px_0px_rgba(156,136,122,0.2)] shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#9c887a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container31() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark3 />
    </div>
  );
}

function Paragraph21() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.45px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Smoky Umber (Foil)</p>
    </div>
  );
}

function LogoShowcase9() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container31 />
      <Paragraph21 />
    </div>
  );
}

function Heading12() {
  return (
    <div className="h-[120px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#f9f6f0] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
    </div>
  );
}

function Paragraph22() {
  return (
    <div className="h-[18px] opacity-80 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#f9f6f0] text-[12px] text-nowrap top-[0.5px] tracking-[1.8px] uppercase whitespace-pre">Ritual Care for Body Modification</p>
    </div>
  );
}

function HolyWordmarkTagline1() {
  return (
    <div className="h-[146px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmarkTagline">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-[146px] items-start relative w-[359.734px]">
        <Heading12 />
        <Paragraph22 />
      </div>
    </div>
  );
}

function Container32() {
  return (
    <div className="bg-[#1a1a1a] h-[242px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[242px] items-center justify-center pl-[0.008px] pr-0 py-0 relative w-full">
          <HolyWordmarkTagline1 />
        </div>
      </div>
    </div>
  );
}

function Paragraph23() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.54px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark + Tagline / Ivory</p>
    </div>
  );
}

function LogoShowcase10() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container32 />
      <Paragraph23 />
    </div>
  );
}

function Heading13() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[378.93px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[378.93px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#d7d0c5] text-[120px] text-nowrap top-0 tracking-[14.4px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div className="bg-[#d7d0c5] h-px opacity-30 relative shrink-0 w-[303.141px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-px w-[303.141px]" />
    </div>
  );
}

function Paragraph24() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#d7d0c5] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyStackedLogo2() {
  return (
    <div className="h-[163px] relative shrink-0 w-[378.93px]" data-name="HOLYStackedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[12px] h-[163px] items-center relative w-[378.93px]">
        <Heading13 />
        <Container33 />
        <Paragraph24 />
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[259px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyStackedLogo2 />
    </div>
  );
}

function Paragraph25() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.36px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Stacked / Limestone Oat</p>
    </div>
  );
}

function LogoShowcase11() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[588.66px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container34 />
      <Paragraph25 />
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[285px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase9 />
      <LogoShowcase10 />
      <LogoShowcase11 />
    </div>
  );
}

function Container36() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[333px] items-start left-[34px] top-[130px] w-[859px]" data-name="Container">
      <Heading11 />
      <Container35 />
    </div>
  );
}

function Heading14() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#f9f6f0] text-[16px] text-nowrap top-[-1px] whitespace-pre">On Relic Green (#5E6458)</p>
    </div>
  );
}

function Heading15() {
  return (
    <div className="basis-0 grow h-[120px] min-h-px min-w-px relative shrink-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-full">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#9c887a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="bg-[#9c887a] h-[84px] opacity-30 relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[84px] w-px" />
    </div>
  );
}

function Paragraph26() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#9c887a] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyHorizontalLogo2() {
  return (
    <div className="h-[120px] relative shadow-[0px_0px_48px_0px_rgba(156,136,122,0.4),0px_2px_16px_0px_rgba(156,136,122,0.2)] shrink-0 w-[486.703px]" data-name="HOLYHorizontalLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex gap-[16px] h-[120px] items-center relative w-[486.703px]">
        <Heading15 />
        <Container37 />
        <Paragraph26 />
      </div>
    </div>
  );
}

function Container38() {
  return (
    <div className="bg-[#5e6458] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyHorizontalLogo2 />
    </div>
  );
}

function Paragraph27() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.46px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Horizontal / Smoky Umber (Foil)</p>
    </div>
  );
}

function LogoShowcase12() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[602px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container38 />
      <Paragraph27 />
    </div>
  );
}

function HolyWordmark4() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#f9f6f0] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="bg-[#5e6458] h-[216px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[216px] items-center justify-center pl-[0.008px] pr-0 py-0 relative w-full">
          <HolyWordmark4 />
        </div>
      </div>
    </div>
  );
}

function Paragraph28() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.17px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Ivory</p>
    </div>
  );
}

function LogoShowcase13() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[602px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container39 />
      <Paragraph28 />
    </div>
  );
}

function HolyMonospacedLogo1() {
  return (
    <div className="h-[480px] relative shrink-0 w-[174.336px]" data-name="HOLYMonospacedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[480px] relative w-[174.336px]">
        <p className="absolute font-['Menlo:Bold',sans-serif] leading-[120px] left-0 not-italic text-[#d7d0c5] text-[120px] top-0 tracking-[24px] uppercase w-[97px]">H Ø L Y</p>
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div className="bg-[#5e6458] content-stretch flex h-[576px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyMonospacedLogo1 />
    </div>
  );
}

function Paragraph29() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.2px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Monospaced / Limestone Oat</p>
    </div>
  );
}

function LogoShowcase14() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[602px] items-start left-[588.66px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container40 />
      <Paragraph29 />
    </div>
  );
}

function Container41() {
  return (
    <div className="h-[602px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase12 />
      <LogoShowcase13 />
      <LogoShowcase14 />
    </div>
  );
}

function Container42() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[650px] items-start left-[34px] top-[511px] w-[859px]" data-name="Container">
      <Heading14 />
      <Container41 />
    </div>
  );
}

function Heading16() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#f9f6f0] text-[16px] text-nowrap top-[-1px] whitespace-pre">On Fogstone Blue (#AAB5B2)</p>
    </div>
  );
}

function HolyWordmark5() {
  return (
    <div className="h-[120px] relative shadow-[0px_0px_48px_0px_rgba(156,136,122,0.4),0px_2px_16px_0px_rgba(156,136,122,0.2)] shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="bg-[#aab5b2] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark5 />
    </div>
  );
}

function Paragraph30() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.24px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Void Black</p>
    </div>
  );
}

function LogoShowcase15() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container43 />
      <Paragraph30 />
    </div>
  );
}

function Heading17() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[378.93px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[378.93px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#f9f6f0] text-[120px] text-nowrap top-0 tracking-[14.4px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container44() {
  return (
    <div className="bg-[#f9f6f0] h-px opacity-30 relative shrink-0 w-[303.141px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-px w-[303.141px]" />
    </div>
  );
}

function Paragraph31() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#f9f6f0] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyStackedLogo3() {
  return (
    <div className="h-[163px] relative shrink-0 w-[378.93px]" data-name="HOLYStackedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[12px] h-[163px] items-center relative w-[378.93px]">
        <Heading17 />
        <Container44 />
        <Paragraph31 />
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div className="bg-[#aab5b2] content-stretch flex h-[259px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyStackedLogo3 />
    </div>
  );
}

function Paragraph32() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.5px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Stacked / Ivory</p>
    </div>
  );
}

function LogoShowcase16() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container45 />
      <Paragraph32 />
    </div>
  );
}

function Heading18() {
  return (
    <div className="basis-0 grow h-[120px] min-h-px min-w-px relative shrink-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-full">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#9c887a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="bg-[#9c887a] h-[84px] opacity-30 relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[84px] w-px" />
    </div>
  );
}

function Paragraph33() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#9c887a] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyHorizontalLogo3() {
  return (
    <div className="h-[120px] relative shadow-[0px_0px_48px_0px_rgba(156,136,122,0.4),0px_2px_16px_0px_rgba(156,136,122,0.2)] shrink-0 w-[486.703px]" data-name="HOLYHorizontalLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex gap-[16px] h-[120px] items-center relative w-[486.703px]">
        <Heading18 />
        <Container46 />
        <Paragraph33 />
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="bg-[#aab5b2] h-[216px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[216px] items-center justify-center pl-[0.008px] pr-0 py-0 relative w-full">
          <HolyHorizontalLogo3 />
        </div>
      </div>
    </div>
  );
}

function Paragraph34() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.47px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Horizontal / Smoky Umber (Foil)</p>
    </div>
  );
}

function LogoShowcase17() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[285px] items-start left-[588.66px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container47 />
      <Paragraph34 />
    </div>
  );
}

function Container48() {
  return (
    <div className="h-[285px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase15 />
      <LogoShowcase16 />
      <LogoShowcase17 />
    </div>
  );
}

function Container49() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[333px] items-start left-[34px] top-[1209px] w-[859px]" data-name="Container">
      <Heading16 />
      <Container48 />
    </div>
  );
}

function Container50() {
  return (
    <div className="bg-[#1a1a1a] h-[1576px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#8c8981] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container30 />
      <Container36 />
      <Container42 />
      <Container49 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p12cddf00} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p22da4ec0} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M2 9H22" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Heading19() {
  return (
    <div className="h-[33.602px] relative shrink-0 w-[199.406px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[33.602px] relative w-[199.406px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[33.6px] left-0 not-italic text-[#1a1a1a] text-[28px] text-nowrap top-[-0.5px] whitespace-pre">Flat / BW System</p>
      </div>
    </div>
  );
}

function Container51() {
  return (
    <div className="content-stretch flex gap-[12px] h-[33.602px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon5 />
      <Heading19 />
    </div>
  );
}

function Paragraph35() {
  return (
    <div className="h-[22.398px] opacity-70 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.4px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-[0.5px] whitespace-pre">Universal black and white logo variants without emboss effects — for maximum flexibility and edge-case applications</p>
    </div>
  );
}

function Container52() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[64px] items-start relative shrink-0 w-full" data-name="Container">
      <Container51 />
      <Paragraph35 />
    </div>
  );
}

function Heading20() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#1a1a1a] text-[16px] text-nowrap top-[-1px] whitespace-pre">Black on White (Primary)</p>
    </div>
  );
}

function HolyWordmark6() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container53() {
  return (
    <div className="bg-white box-border content-stretch flex h-[220px] items-center justify-center p-[2px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <HolyWordmark6 />
    </div>
  );
}

function Paragraph36() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.24px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Void Black</p>
    </div>
  );
}

function LogoShowcase18() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[272px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container53 />
      <Paragraph36 />
    </div>
  );
}

function Heading21() {
  return (
    <div className="h-[120px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
    </div>
  );
}

function Paragraph37() {
  return (
    <div className="h-[18px] opacity-80 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-[0.5px] tracking-[1.8px] uppercase whitespace-pre">Ritual Care for Body Modification</p>
    </div>
  );
}

function HolyWordmarkTagline2() {
  return (
    <div className="h-[146px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmarkTagline">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-[146px] items-start relative w-[359.734px]">
        <Heading21 />
        <Paragraph37 />
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div className="bg-white h-[246px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[246px] items-center justify-center pl-[2.008px] pr-[2px] py-[2px] relative w-full">
          <HolyWordmarkTagline2 />
        </div>
      </div>
    </div>
  );
}

function Paragraph38() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.61px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark + Tagline / Void Black</p>
    </div>
  );
}

function LogoShowcase19() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[272px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container54 />
      <Paragraph38 />
    </div>
  );
}

function Heading22() {
  return (
    <div className="basis-0 grow h-[120px] min-h-px min-w-px relative shrink-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-full">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div className="bg-[#1a1a1a] h-[84px] opacity-30 relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[84px] w-px" />
    </div>
  );
}

function Paragraph39() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyHorizontalLogo4() {
  return (
    <div className="h-[120px] relative shrink-0 w-[486.703px]" data-name="HOLYHorizontalLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex gap-[16px] h-[120px] items-center relative w-[486.703px]">
        <Heading22 />
        <Container55 />
        <Paragraph39 />
      </div>
    </div>
  );
}

function Container56() {
  return (
    <div className="bg-white h-[220px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[220px] items-center justify-center pl-[2.008px] pr-[2px] py-[2px] relative w-full">
          <HolyHorizontalLogo4 />
        </div>
      </div>
    </div>
  );
}

function Paragraph40() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.25px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Horizontal / Void Black</p>
    </div>
  );
}

function LogoShowcase20() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[272px] items-start left-[588.66px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container56 />
      <Paragraph40 />
    </div>
  );
}

function Container57() {
  return (
    <div className="h-[272px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase18 />
      <LogoShowcase19 />
      <LogoShowcase20 />
    </div>
  );
}

function Heading23() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[378.93px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[378.93px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[14.4px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container58() {
  return (
    <div className="bg-[#1a1a1a] h-px opacity-30 relative shrink-0 w-[303.141px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-px w-[303.141px]" />
    </div>
  );
}

function Paragraph41() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyStackedLogo4() {
  return (
    <div className="h-[163px] relative shrink-0 w-[378.93px]" data-name="HOLYStackedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[12px] h-[163px] items-center relative w-[378.93px]">
        <Heading23 />
        <Container58 />
        <Paragraph41 />
      </div>
    </div>
  );
}

function Container59() {
  return (
    <div className="bg-white h-[263px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[263px] items-center justify-center pl-[2.008px] pr-[2px] py-[2px] relative w-full">
          <HolyStackedLogo4 />
        </div>
      </div>
    </div>
  );
}

function Paragraph42() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.57px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Stacked / Void Black</p>
    </div>
  );
}

function LogoShowcase21() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[606px] items-start left-0 top-0 w-[270.328px]" data-name="LogoShowcase">
      <Container59 />
      <Paragraph42 />
    </div>
  );
}

function HolyMonospacedLogo2() {
  return (
    <div className="h-[480px] relative shrink-0 w-[170.336px]" data-name="HOLYMonospacedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[480px] relative w-[170.336px]">
        <p className="absolute font-['Menlo:Bold',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] top-0 tracking-[24px] uppercase w-[97px]">H Ø L Y</p>
      </div>
    </div>
  );
}

function Container60() {
  return (
    <div className="bg-white box-border content-stretch flex h-[580px] items-center justify-center p-[2px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <HolyMonospacedLogo2 />
    </div>
  );
}

function Paragraph43() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[135.41px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Monospaced / Void Black</p>
    </div>
  );
}

function LogoShowcase22() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[606px] items-start left-[294.33px] top-0 w-[270.336px]" data-name="LogoShowcase">
      <Container60 />
      <Paragraph43 />
    </div>
  );
}

function Container61() {
  return (
    <div className="h-[606px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase21 />
      <LogoShowcase22 />
    </div>
  );
}

function Container62() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] h-[950px] items-start relative shrink-0 w-full" data-name="Container">
      <Heading20 />
      <Container57 />
      <Container61 />
    </div>
  );
}

function Heading24() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#f9f6f0] text-[16px] text-nowrap top-[-1px] whitespace-pre">White on Black (Inverted)</p>
    </div>
  );
}

function HolyWordmark7() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#f9f6f0] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container63() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark7 />
    </div>
  );
}

function Paragraph44() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[124.5px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark / Ivory</p>
    </div>
  );
}

function LogoShowcase23() {
  return (
    <div className="[grid-area:1_/_1] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container63 />
      <Paragraph44 />
    </div>
  );
}

function Heading25() {
  return (
    <div className="h-[120px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[120px] text-nowrap text-white top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
    </div>
  );
}

function Paragraph45() {
  return (
    <div className="h-[18px] opacity-80 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[12px] text-nowrap text-white top-[0.5px] tracking-[1.8px] uppercase whitespace-pre">Ritual Care for Body Modification</p>
    </div>
  );
}

function HolyWordmarkTagline3() {
  return (
    <div className="h-[146px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmarkTagline">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[8px] h-[146px] items-start relative w-[359.734px]">
        <Heading25 />
        <Paragraph45 />
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[242px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmarkTagline3 />
    </div>
  );
}

function Paragraph46() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[124.52px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Wordmark + Tagline / Pure White</p>
    </div>
  );
}

function LogoShowcase24() {
  return (
    <div className="[grid-area:1_/_2] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container64 />
      <Paragraph46 />
    </div>
  );
}

function Heading26() {
  return (
    <div className="basis-0 grow h-[120px] min-h-px min-w-px relative shrink-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-full">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#f9f6f0] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container65() {
  return (
    <div className="bg-[#f9f6f0] h-[84px] opacity-30 relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[84px] w-px" />
    </div>
  );
}

function Paragraph47() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[#f9f6f0] text-[12px] text-nowrap top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyHorizontalLogo5() {
  return (
    <div className="h-[120px] relative shrink-0 w-[486.703px]" data-name="HOLYHorizontalLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex gap-[16px] h-[120px] items-center relative w-[486.703px]">
        <Heading26 />
        <Container65 />
        <Paragraph47 />
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyHorizontalLogo5 />
    </div>
  );
}

function Paragraph48() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[124.51px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Horizontal / Ivory</p>
    </div>
  );
}

function LogoShowcase25() {
  return (
    <div className="[grid-area:1_/_3] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container66 />
      <Paragraph48 />
    </div>
  );
}

function Container67() {
  return (
    <div className="gap-[24px] grid grid-cols-[repeat(3,_minmax(0px,_1fr))] grid-rows-[repeat(1,_minmax(0px,_1fr))] h-[268px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase23 />
      <LogoShowcase24 />
      <LogoShowcase25 />
    </div>
  );
}

function Heading27() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[378.93px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-full relative w-[378.93px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[120px] text-nowrap text-white top-0 tracking-[14.4px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container68() {
  return (
    <div className="bg-white h-px opacity-30 relative shrink-0 w-[303.141px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-px w-[303.141px]" />
    </div>
  );
}

function Paragraph49() {
  return (
    <div className="h-[18px] opacity-70 relative shrink-0 w-[93.969px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[93.969px]">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[18px] left-0 not-italic text-[12px] text-nowrap text-white top-[0.5px] tracking-[1.44px] uppercase whitespace-pre">Ritual Care</p>
      </div>
    </div>
  );
}

function HolyStackedLogo5() {
  return (
    <div className="h-[163px] relative shrink-0 w-[378.93px]" data-name="HOLYStackedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[12px] h-[163px] items-center relative w-[378.93px]">
        <Heading27 />
        <Container68 />
        <Paragraph49 />
      </div>
    </div>
  );
}

function Container69() {
  return (
    <div className="bg-[#1a1a1a] h-[259px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="box-border content-stretch flex h-[259px] items-center justify-center pl-[0.008px] pr-0 py-0 relative w-full">
          <HolyStackedLogo5 />
        </div>
      </div>
    </div>
  );
}

function Paragraph50() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[124.98px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Stacked / Pure White</p>
    </div>
  );
}

function LogoShowcase26() {
  return (
    <div className="[grid-area:1_/_1] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container69 />
      <Paragraph50 />
    </div>
  );
}

function HolyMonospacedLogo3() {
  return (
    <div className="h-[480px] relative shrink-0 w-[153px]" data-name="HOLYMonospacedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[480px] relative w-[153px]">
        <p className="absolute font-['Menlo:Bold',sans-serif] leading-[120px] left-0 not-italic text-[#f9f6f0] text-[120px] top-0 tracking-[24px] uppercase w-[97px]">H Ø L Y</p>
      </div>
    </div>
  );
}

function Container70() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[576px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyMonospacedLogo3 />
    </div>
  );
}

function Paragraph51() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[124.67px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Monospaced / Ivory</p>
    </div>
  );
}

function LogoShowcase27() {
  return (
    <div className="[grid-area:1_/_2] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container70 />
      <Paragraph51 />
    </div>
  );
}

function Container71() {
  return (
    <div className="h-[602px] relative shrink-0 w-full" data-name="Container">
      <div className="size-full">
        <div className="box-border gap-[24px] grid grid-cols-[repeat(3,_minmax(0px,_1fr))] grid-rows-[repeat(1,_minmax(0px,_1fr))] h-[602px] pl-0 pr-[273px] py-0 relative w-full">
          <LogoShowcase26 />
          <LogoShowcase27 />
        </div>
      </div>
    </div>
  );
}

function Container72() {
  return (
    <div className="bg-[#1a1a1a] h-[1006px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[24px] h-[1006px] items-start pb-0 pt-[32px] px-[32px] relative w-full">
          <Heading24 />
          <Container67 />
          <Container71 />
        </div>
      </div>
    </div>
  );
}

function Container73() {
  return (
    <div className="bg-white h-[2168px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[32px] h-[2168px] items-start pb-[2px] pt-[34px] px-[34px] relative w-full">
          <Container52 />
          <Container62 />
          <Container72 />
        </div>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p3eebfc00} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M20 2V6" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M22 4H18" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p352890c0} id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Heading28() {
  return (
    <div className="h-[33.602px] relative shrink-0 w-[338.273px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[33.602px] relative w-[338.273px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[33.6px] left-0 not-italic text-[#1a1a1a] text-[28px] text-nowrap top-[-0.5px] whitespace-pre">Complete Brand Color Palette</p>
      </div>
    </div>
  );
}

function Container74() {
  return (
    <div className="content-stretch flex gap-[12px] h-[33.602px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon6 />
      <Heading28 />
    </div>
  );
}

function Paragraph52() {
  return (
    <div className="h-[22.398px] opacity-70 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[22.4px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-[0.5px] whitespace-pre">Wordmark in every brand color on neutral backgrounds</p>
    </div>
  );
}

function Container75() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[64px] items-start relative shrink-0 w-full" data-name="Container">
      <Container74 />
      <Paragraph52 />
    </div>
  );
}

function HolyWordmark8() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#d9c4bb] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container76() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark8 />
    </div>
  );
}

function Paragraph53() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.8px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Veil Clay (#D9C4BB)</p>
    </div>
  );
}

function LogoShowcase28() {
  return (
    <div className="[grid-area:1_/_1] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container76 />
      <Paragraph53 />
    </div>
  );
}

function HolyWordmark9() {
  return (
    <div className="h-[120px] relative shadow-[0px_0px_48px_0px_rgba(156,136,122,0.4),0px_2px_16px_0px_rgba(156,136,122,0.2)] shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#aab5b2] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container77() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark9 />
    </div>
  );
}

function Paragraph54() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.48px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Fogstone Blue (#AAB5B2)</p>
    </div>
  );
}

function LogoShowcase29() {
  return (
    <div className="[grid-area:1_/_2] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container77 />
      <Paragraph54 />
    </div>
  );
}

function HolyWordmark10() {
  return (
    <div className="h-[120px] relative shadow-[0px_0px_48px_0px_rgba(156,136,122,0.4),0px_2px_16px_0px_rgba(156,136,122,0.2)] shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#9c887a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container78() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark10 />
    </div>
  );
}

function Paragraph55() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.69px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Smoky Umber (#9C887A)</p>
    </div>
  );
}

function LogoShowcase30() {
  return (
    <div className="[grid-area:1_/_3] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container78 />
      <Paragraph55 />
    </div>
  );
}

function HolyWordmark11() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#5e6458] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container79() {
  return (
    <div className="bg-[#f9f6f0] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark11 />
    </div>
  );
}

function Paragraph56() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.61px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Relic Green (#5E6458)</p>
    </div>
  );
}

function LogoShowcase31() {
  return (
    <div className="[grid-area:1_/_4] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container79 />
      <Paragraph56 />
    </div>
  );
}

function HolyWordmark12() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#d7d0c5] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container80() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark12 />
    </div>
  );
}

function Paragraph57() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.54px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Limestone Oat (#D7D0C5)</p>
    </div>
  );
}

function LogoShowcase32() {
  return (
    <div className="[grid-area:2_/_1] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container80 />
      <Paragraph57 />
    </div>
  );
}

function HolyWordmark13() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#8c8981] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container81() {
  return (
    <div className="bg-[#f9f6f0] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark13 />
    </div>
  );
}

function Paragraph58() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.65px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Weathered Halo (#8C8981)</p>
    </div>
  );
}

function LogoShowcase33() {
  return (
    <div className="[grid-area:2_/_2] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container81 />
      <Paragraph58 />
    </div>
  );
}

function HolyWordmark14() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#1a1a1a] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container82() {
  return (
    <div className="bg-[#f9f6f0] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark14 />
    </div>
  );
}

function Paragraph59() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.45px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Void Black (#1A1A1A)</p>
    </div>
  );
}

function LogoShowcase34() {
  return (
    <div className="[grid-area:2_/_3] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container82 />
      <Paragraph59 />
    </div>
  );
}

function HolyWordmark15() {
  return (
    <div className="h-[120px] relative shrink-0 w-[359.734px]" data-name="HOLYWordmark">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[120px] relative w-[359.734px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[120px] left-0 not-italic text-[#f9f6f0] text-[120px] text-nowrap top-0 tracking-[9.6px] uppercase whitespace-pre">HØLY</p>
      </div>
    </div>
  );
}

function Container83() {
  return (
    <div className="bg-[#1a1a1a] content-stretch flex h-[216px] items-center justify-center relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <HolyWordmark15 />
    </div>
  );
}

function Paragraph60() {
  return (
    <div className="h-[18px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] not-italic text-[#1a1a1a] text-[12px] text-center text-nowrap top-[0.5px] translate-x-[-50%] whitespace-pre">Ivory Cream (#F9F6F0)</p>
    </div>
  );
}

function LogoShowcase35() {
  return (
    <div className="[grid-area:2_/_4] content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-name="LogoShowcase">
      <Container83 />
      <Paragraph60 />
    </div>
  );
}

function Container84() {
  return (
    <div className="gap-[24px] grid grid-cols-[repeat(4,_minmax(0px,_1fr))] grid-rows-[repeat(2,_minmax(0px,_1fr))] h-[508px] relative shrink-0 w-full" data-name="Container">
      <LogoShowcase28 />
      <LogoShowcase29 />
      <LogoShowcase30 />
      <LogoShowcase31 />
      <LogoShowcase32 />
      <LogoShowcase33 />
      <LogoShowcase34 />
      <LogoShowcase35 />
    </div>
  );
}

function Container85() {
  return (
    <div className="bg-white h-[672px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[32px] h-[672px] items-start pb-[2px] pt-[34px] px-[34px] relative w-full">
          <Container75 />
          <Container84 />
        </div>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p1b851600} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M12 9V13" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M12 17H12.01" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Heading29() {
  return (
    <div className="h-[28.797px] relative shrink-0 w-[169.961px]" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[28.797px] relative w-[169.961px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[28.8px] left-0 not-italic text-[#1a1a1a] text-[24px] text-nowrap top-[0.5px] whitespace-pre">Usage Guidelines</p>
      </div>
    </div>
  );
}

function Container86() {
  return (
    <div className="content-stretch flex gap-[12px] h-[28.797px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon7 />
      <Heading29 />
    </div>
  );
}

function Heading30() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">When to Use Emboss Effects</p>
    </div>
  );
}

function ListItem() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Hero sections and landing pages</p>
    </div>
  );
}

function ListItem1() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Print materials (packaging, labels, business cards)</p>
    </div>
  );
}

function ListItem2() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Premium product photography overlays</p>
    </div>
  );
}

function ListItem3() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Studio signage and environmental graphics</p>
    </div>
  );
}

function List() {
  return (
    <div className="h-[107.188px] opacity-80 relative shrink-0 w-full" data-name="List">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] h-[107.188px] items-start pl-[20px] pr-0 py-0 relative w-full">
          <ListItem />
          <ListItem1 />
          <ListItem2 />
          <ListItem3 />
        </div>
      </div>
    </div>
  );
}

function Container87() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[168.984px] items-start left-0 top-0 w-[413.5px]" data-name="Container">
      <Heading30 />
      <List />
    </div>
  );
}

function Heading31() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">When to Use Flat Logos</p>
    </div>
  );
}

function ListItem4() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Navigation headers and footers</p>
    </div>
  );
}

function ListItem5() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Small sizes (under 60px)</p>
    </div>
  );
}

function ListItem6() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Favicon and app icons</p>
    </div>
  );
}

function ListItem7() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Low-ink printing applications</p>
    </div>
  );
}

function ListItem8() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Email signatures</p>
    </div>
  );
}

function List1() {
  return (
    <div className="h-[135.984px] opacity-80 relative shrink-0 w-full" data-name="List">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] h-[135.984px] items-start pl-[20px] pr-0 py-0 relative w-full">
          <ListItem4 />
          <ListItem5 />
          <ListItem6 />
          <ListItem7 />
          <ListItem8 />
        </div>
      </div>
    </div>
  );
}

function Container88() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[168.984px] items-start left-[445.5px] top-0 w-[413.5px]" data-name="Container">
      <Heading31 />
      <List1 />
    </div>
  );
}

function Heading32() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Accessibility Requirements</p>
    </div>
  );
}

function ListItem9() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Minimum contrast ratio: 4.5:1 (WCAG AA)</p>
    </div>
  );
}

function ListItem10() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Use Void Black or Relic Green on light backgrounds</p>
    </div>
  );
}

function ListItem11() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Use Ivory or Limestone Oat on dark backgrounds</p>
    </div>
  );
}

function ListItem12() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Foil emboss reserved for decorative treatments only</p>
    </div>
  );
}

function List2() {
  return (
    <div className="h-[107.188px] opacity-80 relative shrink-0 w-full" data-name="List">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] h-[107.188px] items-start pl-[20px] pr-0 py-0 relative w-full">
          <ListItem9 />
          <ListItem10 />
          <ListItem11 />
          <ListItem12 />
        </div>
      </div>
    </div>
  );
}

function Container89() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[140.188px] items-start left-0 top-[200.98px] w-[413.5px]" data-name="Container">
      <Heading32 />
      <List2 />
    </div>
  );
}

function Heading33() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">{`File Formats & Export`}</p>
    </div>
  );
}

function ListItem13() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">SVG for web (vector, scalable)</p>
    </div>
  );
}

function ListItem14() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">PNG with transparency for overlays</p>
    </div>
  );
}

function ListItem15() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">PDF for print (CMYK, 300 DPI minimum)</p>
    </div>
  );
}

function ListItem16() {
  return (
    <div className="h-[20.797px] relative shrink-0 w-full" data-name="List Item">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.8px] left-0 not-italic text-[#1a1a1a] text-[13px] text-nowrap top-[0.5px] whitespace-pre">Emboss effects exported as layered files</p>
    </div>
  );
}

function List3() {
  return (
    <div className="h-[107.188px] opacity-80 relative shrink-0 w-full" data-name="List">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] h-[107.188px] items-start pl-[20px] pr-0 py-0 relative w-full">
          <ListItem13 />
          <ListItem14 />
          <ListItem15 />
          <ListItem16 />
        </div>
      </div>
    </div>
  );
}

function Container90() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[140.188px] items-start left-[445.5px] top-[200.98px] w-[413.5px]" data-name="Container">
      <Heading33 />
      <List3 />
    </div>
  );
}

function Container91() {
  return (
    <div className="h-[341.172px] relative shrink-0 w-full" data-name="Container">
      <Container87 />
      <Container88 />
      <Container89 />
      <Container90 />
    </div>
  );
}

function Container92() {
  return (
    <div className="bg-[#f9f6f0] h-[461.969px] relative rounded-[16px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#dadada] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col gap-[24px] h-[461.969px] items-start pb-[2px] pt-[34px] px-[34px] relative w-full">
          <Container86 />
          <Container91 />
        </div>
      </div>
    </div>
  );
}

function LogosPage() {
  return (
    <div className="absolute bg-[#f9f6f0] box-border content-stretch flex flex-col gap-[48px] h-[7215.87px] items-start left-0 pb-0 pl-[312px] pr-[32px] pt-[120px] top-0 w-[1271px]" data-name="LogosPage">
      <Container6 />
      <Container28 />
      <Container50 />
      <Container73 />
      <Container85 />
      <Container92 />
    </div>
  );
}

function Paragraph61() {
  return (
    <div className="h-[16.5px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16.5px] left-0 not-italic text-[#1a1a1a] text-[11px] text-nowrap top-[0.5px] tracking-[0.55px] uppercase whitespace-pre">Foundation</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon" opacity="0.7">
          <path d={svgPaths.p19416e00} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p3e059a80} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6.66667 6H5.33333" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10.6667 8.66667H5.33333" id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10.6667 11.3333H5.33333" id="Vector_5" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Paragraph62() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">File Overview</p>
    </div>
  );
}

function Paragraph63() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">{`Governance & system audit`}</p>
    </div>
  );
}

function Container93() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph62 />
        <Paragraph63 />
      </div>
    </div>
  );
}

function Container94() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon8 />
      <Container93 />
    </div>
  );
}

function Button() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container94 />
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon" opacity="0.7">
          <path d={svgPaths.p2110fac0} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.pc13d040} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M1.33333 6H14.6667" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Paragraph64() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Tokens</p>
    </div>
  );
}

function Paragraph65() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">Color, type, spacing, effects</p>
    </div>
  );
}

function Container95() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph64 />
        <Paragraph65 />
      </div>
    </div>
  );
}

function Container96() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon9 />
      <Container95 />
    </div>
  );
}

function Button1() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container96 />
    </div>
  );
}

function Container97() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[115.594px] items-start relative shrink-0 w-full" data-name="Container">
      <Button />
      <Button1 />
    </div>
  );
}

function Container98() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[140.094px] items-start relative shrink-0 w-full" data-name="Container">
      <Paragraph61 />
      <Container97 />
    </div>
  );
}

function Paragraph66() {
  return (
    <div className="h-[16.5px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16.5px] left-0 not-italic text-[#1a1a1a] text-[11px] text-nowrap top-[0.5px] tracking-[0.55px] uppercase whitespace-pre">Components</p>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon" opacity="0.7">
          <path d={svgPaths.p19d57600} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Paragraph67() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Base Components</p>
    </div>
  );
}

function Paragraph68() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">Buttons, inputs, primitives</p>
    </div>
  );
}

function Container99() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph67 />
        <Paragraph68 />
      </div>
    </div>
  );
}

function Container100() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon10 />
      <Container99 />
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container100 />
    </div>
  );
}

function Icon11() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon" opacity="0.7">
          <path d={svgPaths.p18993c00} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M8 14.6667V8" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p14df0fc0} id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M5 2.84667L11 6.28" id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Paragraph69() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">UI Components</p>
    </div>
  );
}

function Paragraph70() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">Cards, navigation, modules</p>
    </div>
  );
}

function Container101() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph69 />
        <Paragraph70 />
      </div>
    </div>
  );
}

function Container102() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon11 />
      <Container101 />
    </div>
  );
}

function Button3() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container102 />
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_61_3846)" id="Icon" opacity="0.7">
          <path d={svgPaths.p293bce80} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p3d394400} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p9cb0c80} id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M11 7L11.6667 7.66667" id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M11.3333 4L9.406 2.07267" id="Vector_5" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p2ca33580} id="Vector_6" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M13.3333 6L13.9273 6.594" id="Vector_7" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M2.07267 9.406L2.66667 10" id="Vector_8" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4.33333 8.33333L5 9" id="Vector_9" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4.66667 12L6.594 13.9273" id="Vector_10" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p21060e00} id="Vector_11" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_61_3846">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph71() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Ritual Systems</p>
    </div>
  );
}

function Paragraph72() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">System-specific variants</p>
    </div>
  );
}

function Container103() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph71 />
        <Paragraph72 />
      </div>
    </div>
  );
}

function Container104() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon12 />
      <Container103 />
    </div>
  );
}

function Button4() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container104 />
    </div>
  );
}

function Container105() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[175.391px] items-start relative shrink-0 w-full" data-name="Container">
      <Button2 />
      <Button3 />
      <Button4 />
    </div>
  );
}

function Container106() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[199.891px] items-start relative shrink-0 w-full" data-name="Container">
      <Paragraph66 />
      <Container105 />
    </div>
  );
}

function Paragraph73() {
  return (
    <div className="h-[16.5px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16.5px] left-0 not-italic text-[#1a1a1a] text-[11px] text-nowrap top-[0.5px] tracking-[0.55px] uppercase whitespace-pre">Brand Assets</p>
    </div>
  );
}

function Icon13() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_61_3890)" id="Icon">
          <path d={svgPaths.p15ab3e60} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M13.3333 1.33333V4" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M14.6667 2.66667H12" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p22966600} id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_61_3890">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph74() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Logo System</p>
    </div>
  );
}

function Paragraph75() {
  return (
    <div className="h-[16.797px] opacity-70 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">Embossed logo variants</p>
    </div>
  );
}

function Container107() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph74 />
        <Paragraph75 />
      </div>
    </div>
  );
}

function Container108() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon13 />
      <Container107 />
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-[rgba(26,26,26,0.04)] h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container108 />
    </div>
  );
}

function Icon14() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon" opacity="0.7">
          <path d={svgPaths.pad05c0} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p28db2b80} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Paragraph76() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">{`Icons & Marks`}</p>
    </div>
  );
}

function Paragraph77() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">Logos, glyphs, assets</p>
    </div>
  );
}

function Container109() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph76 />
        <Paragraph77 />
      </div>
    </div>
  );
}

function Container110() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon14 />
      <Container109 />
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container110 />
    </div>
  );
}

function Icon15() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_61_3880)" id="Icon" opacity="0.7">
          <path d={svgPaths.pb3f4d00} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p2bdb5600} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M3.33333 4V6.66667" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12.6667 9.33333V12" id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6.66667 1.33333V2.66667" id="Vector_5" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4.66667 5.33333H2" id="Vector_6" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M14 10.6667H11.3333" id="Vector_7" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M7.33333 2H6" id="Vector_8" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_61_3880">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph78() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Motion / States</p>
    </div>
  );
}

function Paragraph79() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">{`Animations & interactions`}</p>
    </div>
  );
}

function Container111() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph78 />
        <Paragraph79 />
      </div>
    </div>
  );
}

function Container112() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon15 />
      <Container111 />
    </div>
  );
}

function Button7() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container112 />
    </div>
  );
}

function Container113() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[175.391px] items-start relative shrink-0 w-full" data-name="Container">
      <Button5 />
      <Button6 />
      <Button7 />
    </div>
  );
}

function Container114() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[199.891px] items-start relative shrink-0 w-full" data-name="Container">
      <Paragraph73 />
      <Container113 />
    </div>
  );
}

function Paragraph80() {
  return (
    <div className="h-[16.5px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16.5px] left-0 not-italic text-[#1a1a1a] text-[11px] text-nowrap top-[0.5px] tracking-[0.55px] uppercase whitespace-pre">{`Print & Packaging`}</p>
    </div>
  );
}

function Icon16() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon" opacity="0.7">
          <path d={svgPaths.p35993080} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M1.33333 6.66667H14.6667" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Paragraph81() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Print Tokens</p>
    </div>
  );
}

function Paragraph82() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">CMYK, Pantone, finishes</p>
    </div>
  );
}

function Container115() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph81 />
        <Paragraph82 />
      </div>
    </div>
  );
}

function Container116() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon16 />
      <Container115 />
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container116 />
    </div>
  );
}

function Icon17() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon" opacity="0.7">
          <path d={svgPaths.pd6c5ec0} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Paragraph83() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Label Templates</p>
    </div>
  );
}

function Paragraph84() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">{`Layouts & dielines`}</p>
    </div>
  );
}

function Container117() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph83 />
        <Paragraph84 />
      </div>
    </div>
  );
}

function Container118() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon17 />
      <Container117 />
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container118 />
    </div>
  );
}

function Icon18() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_61_3876)" id="Icon" opacity="0.7">
          <path d={svgPaths.p9bc8e70} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p8247300} fill="var(--fill-0, #1A1A1A)" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_61_3876">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph85() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Product Labels</p>
    </div>
  );
}

function Paragraph86() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">Complete label designs</p>
    </div>
  );
}

function Container119() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph85 />
        <Paragraph86 />
      </div>
    </div>
  );
}

function Container120() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon18 />
      <Container119 />
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container120 />
    </div>
  );
}

function Icon19() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_61_3816)" id="Icon" opacity="0.7">
          <path d={svgPaths.p3397ec80} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p4adfe2c} id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p27a74a00} id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_61_3816">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Paragraph87() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Print Components</p>
    </div>
  );
}

function Paragraph88() {
  return (
    <div className="h-[16.797px] opacity-50 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] left-0 not-italic text-[#1a1a1a] text-[12px] text-nowrap top-0 whitespace-pre">Bleed, emboss, die-cut</p>
    </div>
  );
}

function Container121() {
  return (
    <div className="basis-0 grow h-[39.797px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[2px] h-[39.797px] items-start relative w-full">
        <Paragraph87 />
        <Paragraph88 />
      </div>
    </div>
  );
}

function Container122() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[39.797px] items-start left-[12px] top-[8px] w-[206px]" data-name="Container">
      <Icon19 />
      <Container121 />
    </div>
  );
}

function Button11() {
  return (
    <div className="h-[55.797px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <Container122 />
    </div>
  );
}

function Container123() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[235.188px] items-start relative shrink-0 w-full" data-name="Container">
      <Button8 />
      <Button9 />
      <Button10 />
      <Button11 />
    </div>
  );
}

function Container124() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[259.688px] items-start relative shrink-0 w-full" data-name="Container">
      <Paragraph80 />
      <Container123 />
    </div>
  );
}

function NavigationContent() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[871.563px] items-start left-[24px] top-[112px] w-[230px]" data-name="NavigationContent">
      <Container98 />
      <Container106 />
      <Container114 />
      <Container124 />
    </div>
  );
}

function Icon20() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon" opacity="0.8">
          <path d={svgPaths.p311d2b80} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Heading34() {
  return (
    <div className="h-[28.797px] relative shrink-0 w-[102px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[28.797px] relative w-[102px]">
        <p className="absolute font-['Tinos:Regular',sans-serif] leading-[28.8px] left-0 not-italic text-[#1a1a1a] text-[24px] text-nowrap top-[0.5px] whitespace-pre">System UI</p>
      </div>
    </div>
  );
}

function Container125() {
  return (
    <div className="content-stretch flex gap-[8px] h-[28.797px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon20 />
      <Heading34 />
    </div>
  );
}

function Paragraph89() {
  return (
    <div className="h-[19.602px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.6px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">HØLY Design System</p>
    </div>
  );
}

function Container126() {
  return (
    <div className="h-[52.398px] relative shrink-0 w-[140.563px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[4px] h-[52.398px] items-start relative w-[140.563px]">
        <Container125 />
        <Paragraph89 />
      </div>
    </div>
  );
}

function Container127() {
  return (
    <div className="absolute bg-white box-border content-stretch flex h-[88px] items-center left-0 pb-[2px] pl-[24px] pr-0 pt-0 top-0 w-[278px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#dadada] border-[0px_0px_2px] border-solid inset-0 pointer-events-none" />
      <Container126 />
    </div>
  );
}

function App() {
  return (
    <div className="absolute bg-white h-[862px] left-0 top-[4031px] w-[280px]" data-name="App">
      <div className="h-[862px] overflow-clip relative rounded-[inherit] w-[280px]">
        <NavigationContent />
        <Container127 />
      </div>
      <div aria-hidden="true" className="absolute border-[#dadada] border-[0px_2px_0px_0px] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Icon21() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon" opacity="0.8">
          <path d={svgPaths.p3eebfc00} id="Vector" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M20 2V6" id="Vector_2" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M22 4H18" id="Vector_3" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p352890c0} id="Vector_4" stroke="var(--stroke-0, #1A1A1A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Heading35() {
  return (
    <div className="h-[33.602px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Tinos:Regular',sans-serif] leading-[33.6px] left-0 not-italic text-[#1a1a1a] text-[28px] text-nowrap top-[-0.5px] whitespace-pre">Logo System</p>
    </div>
  );
}

function Paragraph90() {
  return (
    <div className="h-[21px] opacity-60 relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[21px] left-0 not-italic text-[#1a1a1a] text-[14px] text-nowrap top-0 whitespace-pre">Embossed logo variants</p>
    </div>
  );
}

function Container128() {
  return (
    <div className="basis-0 grow h-[58.602px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex flex-col gap-[4px] h-[58.602px] items-start relative w-full">
        <Heading35 />
        <Paragraph90 />
      </div>
    </div>
  );
}

function Container129() {
  return (
    <div className="h-[58.602px] relative shrink-0 w-[193.844px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border content-stretch flex gap-[12px] h-[58.602px] items-center relative w-[193.844px]">
        <Icon21 />
        <Container128 />
      </div>
    </div>
  );
}

function App1() {
  return (
    <div className="absolute bg-[#f9f6f0] box-border content-stretch flex h-[88px] items-center left-[280px] pb-[2px] pl-[32px] pr-0 pt-0 top-[4031px] w-[991px]" data-name="App">
      <div aria-hidden="true" className="absolute border-[#dadada] border-[0px_0px_2px] border-solid inset-0 pointer-events-none" />
      <Container129 />
    </div>
  );
}

export default function HolyDesignSystem() {
  return (
    <div className="bg-[#f9f6f0] relative size-full" data-name="📂 HØLY™ Design System">
      <LogosPage />
      <App />
      <App1 />
    </div>
  );
}