# HØLY™ Label Design Philosophy — Sacred Minimalism

## 🎯 Design Vision

**"A label should whisper luxury, not shout it."**

HØLY labels exist at the intersection of apothecary heritage, contemporary wellness, and sacred ritual. They honor the product within while elevating the entire brand experience. Every element serves both functional clarity and emotional resonance.

---

## 🏛️ Core Principles

### 1. **Sacred Minimalism**
Not austere. Not cold. But refined, intentional, and deeply considered.
- **More white space than ink** — Let the design breathe
- **Asymmetric balance** — Organic, not mechanical
- **Soft geometry** — Rounded corners, gentle borders, subtle dividers
- **Layered hierarchy** — Guide the eye naturally from brand → product → ritual

### 2. **Typographic Soul**
Typography carries the entire emotional weight of the brand.
- **Garamond (Display)** — Sacred, editorial, timeless. Used for brand name, product name, and poetic descriptions
- **Inter (Body)** — Clean, legible, modern. Used for instructions, ingredients, regulatory text
- **Hierarchy through scale + weight, not color** — Black on ivory, always
- **Tight letter-spacing for Garamond** — `-0.01em` to `-0.02em` for elegance
- **Wide letter-spacing for Inter labels** — `0.05em` to `0.08em` for clarity

### 3. **Ritual System Color Coding**
Each of the 5 ritual systems has a signature color. On labels, it appears as:
- **Subtle accent line** — 2px divider, 24-40px wide
- **Ritual badge background** — Small, refined pill shape with white text
- **Purpose badges** — Gentle tint (8-12% opacity) with colored border
- **Never dominant** — The color supports, it doesn't overwhelm

**Ritual Colors:**
- Ritual Aftercare™ → Fogstone Blue `#AAB5B2`
- Ritual Renewal™ → Veil Clay `#D9C4BB`
- Ritual Touch™ → Relic Green `#5E6458`
- Ritual Union™ → Limestone Oat `#D7D0C5`
- Ritual Vital™ → Smoky Umber `#9C887A`

### 4. **Information Architecture**
Every label follows a consistent vertical rhythm:

**TOP THIRD — Brand Identity**
- HØLY™ brand mark (Garamond, 20-24px)
- Ritual color accent line (2px × 32-40px)
- Product name (Garamond, 28-36px, hero size)
- Ritual system badge (Inter uppercase, 9-10px)

**MIDDLE THIRD — Function & Story**
- Purpose badges (Cleanse, Protect, Hydrate, etc.)
- Core ingredient or material (Inter, 10-12px, 70% opacity)
- Poetic functional description (Garamond italic, 12-14px, 80% opacity)

**BOTTOM THIRD — Usage & Compliance**
- Usage ritual instructions (Inter, 10-12px)
- Volume/size (Inter, 9-10px, 60% opacity)
- SKU code (Monospace, 7-8px, 40% opacity)
- Optional: batch code, regulatory symbols

### 5. **Material Considerations**
Labels are designed for premium production:
- **Substrate:** Uncoated cream or textured ivory paper
- **Finish:** Matte with optional subtle spot UV on brand mark
- **Printing:** Letterpress-style deboss on product name (optional)
- **Application:** Self-adhesive for bottles, swing tags for tools/textiles
- **Size range:** 2" × 3" (small bottles) up to 4" × 6" (boxes/packaging)

---

## 📐 Label Structure (Visual Hierarchy)

```
┌─────────────────────────┐
│                         │
│        HØLY™            │ ← Brand mark (Garamond, centered)
│         ——              │ ← Ritual color line
│      hølymist™          │ ← Product name (Garamond, large)
│   [Ritual Aftercare™]   │ ← System badge (colored pill)
│                         │
│   ┌─────────┐           │
│   │ Cleanse │ Hydrate   │ ← Purpose badges (outlined)
│   └─────────┘           │
│                         │
│  0.9% sterile saline    │ ← Core ingredient (Inter, subdued)
│                         │
│  Gently cleanses and    │ ← Poetic description (Garamond italic)
│  hydrates fresh         │
│  piercings              │
│                         │
│    DAILY RITUAL         │ ← Usage label (Inter uppercase, tiny)
│  Spray 2–3 times daily  │ ← Usage instruction
│                         │
│  ─────────────────────  │ ← Divider (subtle)
│  100mL / 3.38 fl oz     │ ← Volume (Inter, small)
│  HOLY-AFT-001           │ ← SKU (monospace, smallest)
│                         │
└─────────────────────────┘
```

---

## 🎨 Color & Contrast Philosophy

**Background:** Always Ivory `#F9F6F0` or pure white `#FFFFFF`  
**Primary Text:** Temple Black `#1A1A1A`  
**Secondary Text:** Temple Black at 70-80% opacity  
**Tertiary Text:** Temple Black at 40-60% opacity  

**Ritual Accent Color:** Used at 100% for lines/badges, 8-12% for tinted backgrounds

**WCAG AAA Compliance:**
- All body text 11px+ meets AAA standards (7:1 ratio on ivory)
- All badge text on colored backgrounds is white for maximum contrast
- No gray text below 10px font size

---

## 🔤 Typography Specifications

### Garamond (Display / Editorial)
**Used for:** Brand name, product name, poetic descriptions

| Element | Size | Weight | Letter-spacing | Line-height |
|---------|------|--------|----------------|-------------|
| Brand mark (HØLY™) | 20-24px | 500 | 0.02em | 1.0 |
| Product name | 28-36px | 500 | -0.01em | 1.1 |
| Description (italic) | 12-14px | 400 | 0 | 1.5 |

### Inter (Body / Functional)
**Used for:** Instructions, ingredients, regulatory text, badges

| Element | Size | Weight | Letter-spacing | Line-height |
|---------|------|--------|----------------|-------------|
| Ritual badge | 9-10px | 500 | 0.05em | 1.0 |
| Purpose badge | 9px | 500 | 0.03em | 1.0 |
| Ingredient list | 10-12px | 400 | 0 | 1.4 |
| Usage instructions | 10-12px | 400 | 0 | 1.4 |
| Volume/regulatory | 9-10px | 400 | 0 | 1.0 |

### SF Mono (Monospace)
**Used for:** SKU codes, batch numbers

| Element | Size | Weight | Letter-spacing | Line-height |
|---------|------|--------|----------------|-------------|
| SKU code | 7-8px | 400 | 0.02em | 1.0 |

---

## 🎭 Ritual System Differentiation

Each ritual system maintains the same label structure but varies the accent color and badge:

### Ritual Aftercare™ (Medical-adjacent healing)
- **Color:** Fogstone Blue `#AAB5B2` (cool, clinical, calming)
- **Vibe:** Clean, protective, gentle
- **Products:** hølymist™, hølyrest™, hølyveil™, hølyguard™, etc.

### Ritual Renewal™ (Skincare & beauty)
- **Color:** Veil Clay `#D9C4BB` (warm, soft, nurturing)
- **Vibe:** Restorative, luxurious, indulgent
- **Products:** Light Prep Serum, Retinol Alternative Moisturiser, etc.

### Ritual Touch™ (Body tools & massage)
- **Color:** Relic Green `#5E6458` (natural, grounded, earthy)
- **Vibe:** Tactile, sensory, embodied
- **Products:** Jade Gua Sha, Obsidian Massage Wand, etc.

### Ritual Union™ (Intimacy & connection)
- **Color:** Limestone Oat `#D7D0C5` (neutral, warm, inviting)
- **Vibe:** Sensual, bonding, vulnerable
- **Products:** Intimacy Card Deck, Sensual Candle Set, etc.

### Ritual Vital™ (Wellness & vitality)
- **Color:** Smoky Umber `#9C887A` (rich, deep, energizing)
- **Vibe:** Active, intentional, empowering
- **Products:** Breathwork Guide Cards, Moon Cycle Tracker, etc.

---

## 📏 Label Sizes & Applications

### Small Format (2" × 2.5" / 50mm × 63mm)
**For:** Travel sizes, sample vials, small bottles
- Simplified content: Brand + product name + volume only
- Single ritual badge, no purpose badges
- Minimal instructions ("See insert for usage")

### Standard Format (2.5" × 3.5" / 63mm × 89mm)
**For:** Standard bottles (100-200mL), jars, tubes
- Full information hierarchy (TOP → MIDDLE → BOTTOM)
- All badges, descriptions, usage instructions
- This is the **primary label format** for most products

### Large Format (4" × 5" / 102mm × 127mm)
**For:** Boxes, kits, bundles, large containers
- Expanded descriptions with more ritual storytelling
- Multiple product listings (for kits)
- Ingredient lists, certifications, extended instructions
- Optional: illustrations, botanical drawings

### Tag Format (2" × 3" / 50mm × 76mm)
**For:** Tools, textiles, cards, non-liquid products
- Swing tag or tied attachment
- Less regulatory text, more story/ritual guidance
- Optional hole punch at top for attachment

---

## ✨ Production Details

### Print Specifications
- **Resolution:** 300 DPI minimum
- **Color mode:** CMYK (convert from brand RGB palette)
- **Bleed:** 3mm (0.125") on all sides
- **Safe area:** 3mm (0.125") inset from trim

### Font Embedding
- Garamond: EB Garamond (Google Fonts, OFL license)
- Inter: Inter (Google Fonts, OFL license)
- SF Mono: System fallback or Monaco

### File Formats
- **Design source:** Figma or Adobe Illustrator
- **Print-ready:** PDF/X-1a with embedded fonts
- **Digital preview:** PNG at 2× resolution (600 DPI)

---

## 🧪 Testing & Validation

Before finalizing any label:
- ✅ **Legibility test:** Print at actual size, read from 18" distance
- ✅ **Contrast validation:** Run WCAG checker on all text/background pairs
- ✅ **Trademark compliance:** All ™ symbols properly positioned at 12% size
- ✅ **Regulatory review:** All required information present (volume, SKU, compliance)
- ✅ **Material mockup:** Test on actual substrate with actual printing method
- ✅ **Brand consistency:** Compare against other ritual system labels

---

## 🎓 Design Decision Framework

When creating a new label, ask:

1. **Does it feel HØLY?** (Sacred, refined, intentional — not trendy or cheap)
2. **Is the hierarchy clear?** (Eye flows: brand → product → ritual → usage)
3. **Does the ritual color support, not dominate?** (Accent, not hero)
4. **Can you read it at arm's length?** (Legibility > decoration)
5. **Would this age well in 5 years?** (Timeless > trendy)
6. **Does it honor the product inside?** (Premium feel matches premium quality)

---

## 📚 Reference & Inspiration

**Brands with similar label aesthetics:**
- Aesop (minimalist apothecary, typographic focus)
- Le Labo (craft aesthetic, handwritten elements)
- Byredo (Scandinavian minimalism, refined)
- Herbivore Botanicals (clean, botanical, soft)
- Kjaer Weis (luxury minimalism, metal cases)

**What HØLY does differently:**
- More warmth (vs. Aesop's clinical coldness)
- More refinement (vs. Le Labo's rough craft)
- More ritual language (vs. functional product copy)
- Sacred intention embedded in every element

---

**Last Updated:** November 2025  
**Version:** 1.0 — Sacred Minimalism  
**Status:** ✅ Active Design System
