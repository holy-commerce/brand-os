import { TM } from '../../components/core-system';
import { HOLYEye } from '../../components/icons/HOLYIcons';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

/**
 * ========================================
 * TOKENS PAGE — NORMALIZED v2.0
 * HØLY | Ritual Care™ Design System
 * ========================================
 * 
 * Complete, normalized token system for Shopify theme conversion.
 * Structured for direct translation into CSS variables.
 * 
 * Engineering Handoff:
 * - Export as CSS variables in theme.liquid
 * - Map to Shopify theme settings for brand customization
 * - Distinguish between brand-overridable and system-fixed tokens
 * - All tokens are platform-agnostic (CSS, Shopify, Email)
 */

export default function TokensPage() {
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  const handleCopy = (value: string, name: string) => {
    navigator.clipboard.writeText(value);
    setCopiedToken(name);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  // Color tokens - NORMALIZED
  const colorTokens = {
    semantic: [
      { name: '--color-temple-black', value: '#1A1A1A', usage: 'Primary text, headers, dark backgrounds', overridable: false },
      { name: '--color-ritual-white', value: '#F9F6F0', usage: 'Page backgrounds, light surfaces', overridable: false },
      { name: '--color-fogstone-blue', value: '#AAB5B2', usage: 'Secondary surfaces, muted accents', overridable: true },
      { name: '--color-veil-clay', value: '#D9C4BB', usage: 'Warm accents, hero backgrounds', overridable: true },
      { name: '--color-relic-green', value: '#5E6458', usage: 'Tertiary accents, subtle borders', overridable: true },
      { name: '--color-limestone-oat', value: '#D7D0C5', usage: 'Pulsing Ø animation, soft highlights', overridable: true },
      { name: '--color-smoky-umber', value: '#9C887A', usage: 'Rich backgrounds (white text required)', overridable: true },
      { name: '--color-weathered-halo', value: '#8C8981', usage: 'Muted text, disabled states', overridable: true },
    ],
    functional: [
      { name: '--color-background-primary', value: '#F9F6F0', usage: 'Page background', overridable: false },
      { name: '--color-background-secondary', value: '#FFFFFF', usage: 'Card/elevated surfaces', overridable: false },
      { name: '--color-background-tertiary', value: '#D7D0C5', usage: 'Subtle backgrounds', overridable: false },
      { name: '--color-background-inverse', value: '#1A1A1A', usage: 'Dark backgrounds', overridable: false },
      { name: '--color-background-rich', value: '#9C887A', usage: 'Smoky Umber (requires white text)', overridable: false },
      { name: '--color-text-primary', value: '#1A1A1A', usage: 'Body text on light backgrounds', overridable: false },
      { name: '--color-text-secondary', value: '#8C8981', usage: 'Muted text, captions', overridable: false },
      { name: '--color-text-inverse', value: '#F9F6F0', usage: 'Text on dark backgrounds', overridable: false },
      { name: '--color-text-disabled', value: 'rgba(26, 26, 26, 0.4)', usage: 'Disabled text state', overridable: false },
      { name: '--color-border-default', value: '#DADADA', usage: 'Standard borders, dividers', overridable: false },
      { name: '--color-border-subtle', value: 'rgba(26, 26, 26, 0.1)', usage: 'Subtle borders', overridable: false },
      { name: '--color-border-strong', value: '#1A1A1A', usage: 'Strong borders, emphasis', overridable: false },
      { name: '--color-accent-primary', value: '#5E6458', usage: 'Relic Green - primary accent', overridable: true },
      { name: '--color-accent-secondary', value: '#AAB5B2', usage: 'Fogstone Blue - secondary accent', overridable: true },
      { name: '--color-accent-tertiary', value: '#D9C4BB', usage: 'Veil Clay - tertiary accent', overridable: true },
    ],
    states: [
      { name: '--color-state-hover', value: 'rgba(26, 26, 26, 0.05)', usage: 'Hover state background', overridable: false },
      { name: '--color-state-active', value: 'rgba(26, 26, 26, 0.1)', usage: 'Active/pressed state', overridable: false },
      { name: '--color-state-disabled', value: '#8C8981', usage: 'Disabled state color', overridable: false },
      { name: '--color-state-focus', value: '#5E6458', usage: 'Focus outline color (ADA)', overridable: false },
    ],
    semantic_feedback: [
      { name: '--color-success', value: '#5E6458', usage: 'Success messages, confirmations', overridable: true },
      { name: '--color-error', value: '#8C4A3A', usage: 'Error messages, warnings', overridable: true },
      { name: '--color-warning', value: '#9C887A', usage: 'Warning states', overridable: true },
      { name: '--color-info', value: '#AAB5B2', usage: 'Informational messages', overridable: true },
    ],
    opacity: [
      { name: '--opacity-disabled', value: '0.4', usage: 'Disabled elements', overridable: false },
      { name: '--opacity-muted', value: '0.6', usage: 'Muted text, subtle elements', overridable: false },
      { name: '--opacity-medium', value: '0.8', usage: 'Medium opacity', overridable: false },
      { name: '--opacity-full', value: '1', usage: 'Full opacity', overridable: false },
    ],
  };

  // Typography tokens - NORMALIZED
  const typographyTokens = {
    families: [
      { name: '--font-family-display', value: 'Garamond, serif', usage: 'Headlines, HØLY logotype, display text' },
      { name: '--font-family-body', value: 'Inter, sans-serif', usage: 'Body text, UI elements, labels' },
    ],
    sizes: [
      { name: '--font-size-xs', value: '0.75rem', px: '12px', usage: 'Legal text, microcopy' },
      { name: '--font-size-sm', value: '0.875rem', px: '14px', usage: 'Small body text, labels' },
      { name: '--font-size-base', value: '1rem', px: '16px', usage: 'Default body text' },
      { name: '--font-size-lg', value: '1.125rem', px: '18px', usage: 'Large body text, intro paragraphs' },
      { name: '--font-size-xl', value: '1.25rem', px: '20px', usage: 'Subheadings' },
      { name: '--font-size-2xl', value: '1.5rem', px: '24px', usage: 'Section titles' },
      { name: '--font-size-3xl', value: '2rem', px: '32px', usage: 'Page titles' },
      { name: '--font-size-4xl', value: '3rem', px: '48px', usage: 'Hero headlines' },
      { name: '--font-size-5xl', value: '4rem', px: '64px', usage: 'Display headlines' },
      { name: '--font-size-6xl', value: '6rem', px: '96px', usage: 'Landing hero, maximum impact' },
    ],
    weights: [
      { name: '--font-weight-light', value: '300', usage: 'Display text, elegant headlines' },
      { name: '--font-weight-regular', value: '400', usage: 'Body text' },
      { name: '--font-weight-medium', value: '500', usage: 'Emphasis, button labels' },
      { name: '--font-weight-semibold', value: '600', usage: 'Strong emphasis, navigation' },
      { name: '--font-weight-bold', value: '700', usage: 'Maximum emphasis (use sparingly)' },
    ],
    lineHeights: [
      { name: '--line-height-tight', value: '1.1', usage: 'Display headlines (110%)' },
      { name: '--line-height-snug', value: '1.2', usage: 'Headings (120%)' },
      { name: '--line-height-normal', value: '1.4', usage: 'UI elements (140%)' },
      { name: '--line-height-relaxed', value: '1.6', usage: 'Body text (160%)' },
      { name: '--line-height-loose', value: '1.8', usage: 'Long-form content (180%)' },
    ],
    letterSpacing: [
      { name: '--letter-spacing-tight', value: '-0.02em', usage: 'Large display text' },
      { name: '--letter-spacing-normal', value: '0', usage: 'Default spacing' },
      { name: '--letter-spacing-wide', value: '0.02em', usage: 'Slight tracking' },
      { name: '--letter-spacing-wider', value: '0.05em', usage: 'Labels, small caps' },
      { name: '--letter-spacing-widest', value: '0.1em', usage: 'All-caps labels' },
    ],
  };

  // Spacing tokens - NORMALIZED
  const spacingTokens = [
    { name: '--space-0', value: '0', px: '0px', usage: 'Zero spacing (explicit)' },
    { name: '--space-xs', value: '0.25rem', px: '4px', usage: 'Tight icon gaps, trademark spacing' },
    { name: '--space-sm', value: '0.5rem', px: '8px', usage: 'Small gaps, compact layouts' },
    { name: '--space-md', value: '1rem', px: '16px', usage: 'Default component spacing' },
    { name: '--space-lg', value: '1.5rem', px: '24px', usage: 'Section spacing, card padding' },
    { name: '--space-xl', value: '2rem', px: '32px', usage: 'Large section gaps' },
    { name: '--space-2xl', value: '3rem', px: '48px', usage: 'Major section dividers' },
    { name: '--space-3xl', value: '4rem', px: '64px', usage: 'Page sections' },
    { name: '--space-4xl', value: '6rem', px: '96px', usage: 'Hero padding, maximum breathing room' },
  ];

  // Sizing & Layout tokens - NEW
  const layoutTokens = {
    contentWidths: [
      { name: '--content-width-xs', value: '20rem', px: '320px', usage: 'Narrow forms' },
      { name: '--content-width-sm', value: '24rem', px: '384px', usage: 'Compact content' },
      { name: '--content-width-md', value: '28rem', px: '448px', usage: 'Standard forms' },
      { name: '--content-width-lg', value: '32rem', px: '512px', usage: 'Reading width' },
      { name: '--content-width-xl', value: '42rem', px: '672px', usage: 'Comfortable reading' },
      { name: '--content-width-2xl', value: '48rem', px: '768px', usage: 'Wide content' },
      { name: '--content-width-3xl', value: '56rem', px: '896px', usage: 'Full content' },
      { name: '--content-width-4xl', value: '64rem', px: '1024px', usage: 'Container max' },
      { name: '--content-width-5xl', value: '80rem', px: '1280px', usage: 'Page max' },
      { name: '--content-width-full', value: '100%', px: '100%', usage: 'Full width' },
    ],
    containerPadding: [
      { name: '--container-padding-mobile', value: '1rem', px: '16px', usage: 'Mobile container padding' },
      { name: '--container-padding-tablet', value: '1.5rem', px: '24px', usage: 'Tablet container padding' },
      { name: '--container-padding-desktop', value: '2rem', px: '32px', usage: 'Desktop container padding' },
    ],
    gridGaps: [
      { name: '--grid-gap-sm', value: '0.5rem', px: '8px', usage: 'Tight grid spacing' },
      { name: '--grid-gap-md', value: '1rem', px: '16px', usage: 'Default grid spacing' },
      { name: '--grid-gap-lg', value: '1.5rem', px: '24px', usage: 'Comfortable grid spacing' },
      { name: '--grid-gap-xl', value: '2rem', px: '32px', usage: 'Spacious grid layout' },
    ],
  };

  // Radius tokens - NORMALIZED
  const radiusTokens = [
    { name: '--radius-none', value: '0', usage: 'No rounding' },
    { name: '--radius-sm', value: '0.25rem', px: '4px', usage: 'Small elements, tags' },
    { name: '--radius-md', value: '0.5rem', px: '8px', usage: 'Buttons, inputs, cards' },
    { name: '--radius-lg', value: '0.75rem', px: '12px', usage: 'Large cards, modals' },
    { name: '--radius-xl', value: '1rem', px: '16px', usage: 'Hero containers, feature blocks' },
    { name: '--radius-2xl', value: '1.5rem', px: '24px', usage: 'Maximum luxury rounding' },
    { name: '--radius-full', value: '9999px', px: '9999px', usage: 'Pills, circular elements' },
  ];

  // Border & Outline tokens - NEW
  const borderTokens = {
    widths: [
      { name: '--border-width-none', value: '0', usage: 'No border' },
      { name: '--border-width-thin', value: '1px', usage: 'Standard borders' },
      { name: '--border-width-medium', value: '2px', usage: 'Emphasized borders' },
      { name: '--border-width-thick', value: '4px', usage: 'Strong emphasis' },
    ],
    styles: [
      { name: '--border-style-solid', value: 'solid', usage: 'Standard borders' },
      { name: '--border-style-dashed', value: 'dashed', usage: 'Dashed borders' },
      { name: '--border-style-none', value: 'none', usage: 'No border' },
    ],
    focus: [
      { name: '--outline-width-focus', value: '2px', usage: 'Focus outline width (ADA)' },
      { name: '--outline-style-focus', value: 'solid', usage: 'Focus outline style' },
      { name: '--outline-color-focus', value: '#5E6458', usage: 'Focus outline color (Relic Green)' },
      { name: '--outline-offset-focus', value: '2px', usage: 'Focus outline offset' },
    ],
  };

  // Elevation tokens - NORMALIZED
  const elevationTokens = [
    { name: '--shadow-none', value: 'none', usage: 'No shadow' },
    { name: '--shadow-xs', value: '0 1px 2px rgba(26, 26, 26, 0.05)', usage: 'Subtle lift, borders' },
    { name: '--shadow-sm', value: '0 1px 3px rgba(26, 26, 26, 0.08)', usage: 'Cards, dropdowns' },
    { name: '--shadow-md', value: '0 4px 8px rgba(26, 26, 26, 0.1)', usage: 'Elevated cards, navigation' },
    { name: '--shadow-lg', value: '0 8px 16px rgba(26, 26, 26, 0.12)', usage: 'Modals, popovers' },
    { name: '--shadow-xl', value: '0 12px 24px rgba(26, 26, 26, 0.15)', usage: 'Maximum elevation' },
  ];

  // Motion tokens - NORMALIZED with presets
  const motionTokens = {
    duration: [
      { name: '--duration-instant', value: '100ms', usage: 'Micro-interactions, hovers' },
      { name: '--duration-fast', value: '200ms', usage: 'Button states, toggles' },
      { name: '--duration-normal', value: '300ms', usage: 'Default transitions' },
      { name: '--duration-slow', value: '500ms', usage: 'Page transitions, reveals' },
      { name: '--duration-slower', value: '800ms', usage: 'Slow animations' },
      { name: '--duration-ambient', value: '3000ms', usage: 'Pulsing Ø, ambient animations' },
    ],
    easing: [
      { name: '--easing-linear', value: 'linear', usage: 'Linear transitions' },
      { name: '--easing-default', value: 'ease-in-out', usage: 'Standard transitions' },
      { name: '--easing-ease-in', value: 'ease-in', usage: 'Enter transitions' },
      { name: '--easing-ease-out', value: 'ease-out', usage: 'Exit transitions' },
      { name: '--easing-enter', value: 'cubic-bezier(0.4, 0, 0.2, 1)', usage: 'Custom enter animations' },
      { name: '--easing-exit', value: 'cubic-bezier(0.4, 0, 1, 1)', usage: 'Custom exit animations' },
    ],
    presets: [
      { name: '--transition-fast', value: 'all 200ms ease-in-out', usage: 'Fast transitions' },
      { name: '--transition-normal', value: 'all 300ms ease-in-out', usage: 'Default transitions' },
      { name: '--transition-slow', value: 'all 500ms ease-in-out', usage: 'Slow transitions' },
    ],
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F9F6F0' }}>
      <div className="max-w-7xl mx-auto p-8 space-y-20">
        
        {/* Page Header */}
        <div className="space-y-6">
          <div className="p-8 rounded-2xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #DADADA' }}>
            <div className="flex items-center gap-3 mb-3">
              <HOLYEye size={32} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
              <h1 style={{ fontFamily: 'Garamond, serif', fontSize: '36px', fontWeight: '500', color: '#1A1A1A', lineHeight: '120%', margin: 0 }}>
                Design Tokens — Normalized v2.0
              </h1>
            </div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', lineHeight: '160%', opacity: 0.7, marginBottom: '16px' }}>
              Complete, production-ready token system for HØLY | Ritual Care<TM />. Structured for direct translation into CSS variables and Shopify themes.
            </p>
            <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F6F0', border: '1px solid #DADADA' }}>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#1A1A1A', lineHeight: '160%', opacity: 0.6, margin: 0 }}>
                <strong>Engineering Handoff:</strong> Brand-overridable tokens can be exposed in Shopify theme settings. System-fixed tokens ensure ADA/WCAG AAA compliance and should remain locked. All tokens are platform-agnostic (CSS, Shopify, Email).
              </p>
            </div>
          </div>
        </div>

        {/* Color Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Color Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              Complete color system with semantic, functional, state, and feedback colors. All text on Smoky Umber and Temple Black must use white for WCAG AAA compliance.
            </p>
          </div>

          <div className="space-y-6">
            {/* Semantic Colors */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Semantic Colors (Brand Layer)
              </h3>
              <div className="space-y-2">
                {colorTokens.semantic.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg flex items-center gap-4"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div 
                      style={{ 
                        width: '64px', 
                        height: '64px', 
                        backgroundColor: token.value,
                        borderRadius: '8px',
                        border: '1px solid #DADADA',
                        flexShrink: 0,
                      }}
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <code style={{ fontFamily: 'monospace', fontSize: '13px', color: '#1A1A1A', fontWeight: '500' }}>
                          {token.name}
                        </code>
                        {token.overridable && (
                          <span style={{ 
                            fontFamily: 'Inter, sans-serif', 
                            fontSize: '10px', 
                            color: '#5E6458', 
                            backgroundColor: '#D7D0C5',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            textTransform: 'uppercase',
                            fontWeight: '600',
                          }}>
                            Brand Override
                          </span>
                        )}
                      </div>
                      <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#1A1A1A', opacity: 0.6, marginBottom: '4px' }}>
                        {token.usage}
                      </p>
                      <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#8C8981' }}>
                        {token.value}
                      </code>
                    </div>
                    <button
                      onClick={() => handleCopy(token.value, token.name)}
                      style={{
                        padding: '8px',
                        borderRadius: '6px',
                        border: '1px solid #DADADA',
                        backgroundColor: copiedToken === token.name ? '#D7D0C5' : '#F9F6F0',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                      }}
                    >
                      {copiedToken === token.name ? <Check size={16} color="#5E6458" /> : <Copy size={16} color="#1A1A1A" />}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Functional Colors */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Functional Colors (Role-Based)
              </h3>
              <div className="grid md:grid-cols-2 gap-2">
                {colorTokens.functional.map((token) => (
                  <div 
                    key={token.name}
                    className="p-3 rounded-lg flex items-center gap-3"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div 
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: token.value.includes('rgba') ? 'transparent' : token.value,
                        borderRadius: '6px',
                        border: '1px solid #DADADA',
                        flexShrink: 0,
                        background: token.value.includes('rgba') 
                          ? `linear-gradient(135deg, ${token.value} 50%, #FFFFFF 50%)`
                          : token.value,
                      }}
                    />
                    <div className="flex-1 min-w-0">
                      <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '2px' }}>
                        {token.name}
                      </code>
                      <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6 }}>
                        {token.usage}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* State Colors */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                State Colors
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {colorTokens.states.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <button
                        onClick={() => handleCopy(token.value, token.name)}
                        style={{
                          padding: '6px',
                          borderRadius: '6px',
                          border: '1px solid #DADADA',
                          backgroundColor: copiedToken === token.name ? '#D7D0C5' : '#F9F6F0',
                          cursor: 'pointer',
                        }}
                      >
                        {copiedToken === token.name ? <Check size={14} color="#5E6458" /> : <Copy size={14} color="#1A1A1A" />}
                      </button>
                    </div>
                    <div 
                      style={{ 
                        height: '40px',
                        backgroundColor: token.value.includes('rgba') ? 'transparent' : token.value,
                        borderRadius: '6px',
                        border: '1px solid #DADADA',
                        marginBottom: '8px',
                        background: token.value.includes('rgba') 
                          ? `linear-gradient(135deg, ${token.value} 50%, #FFFFFF 50%)`
                          : token.value,
                      }}
                    />
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6, marginBottom: '4px' }}>
                      {token.usage}
                    </p>
                    <code style={{ fontFamily: 'monospace', fontSize: '10px', color: '#8C8981' }}>
                      {token.value}
                    </code>
                  </div>
                ))}
              </div>
            </div>

            {/* Semantic Feedback Colors */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Semantic Feedback
              </h3>
              <div className="grid md:grid-cols-4 gap-3">
                {colorTokens.semantic_feedback.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
                      {token.name}
                    </code>
                    <div 
                      style={{ 
                        height: '32px',
                        backgroundColor: token.value,
                        borderRadius: '6px',
                        marginBottom: '6px',
                      }}
                    />
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Opacity Scale */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Opacity Scale
              </h3>
              <div className="grid md:grid-cols-4 gap-3">
                {colorTokens.opacity.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                        {token.value}
                      </span>
                    </div>
                    <div 
                      style={{ 
                        height: '32px',
                        backgroundColor: '#1A1A1A',
                        borderRadius: '6px',
                        opacity: parseFloat(token.value),
                        marginBottom: '6px',
                      }}
                    />
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Typography Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Typography Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              Complete type system with families, sizes (rem-based), weights, line-heights, and letter-spacing. Garamond for display, Inter for body and UI.
            </p>
          </div>

          <div className="space-y-6">
            {/* Font Families */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Font Families
              </h3>
              <div className="space-y-2">
                {typographyTokens.families.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '13px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <button
                        onClick={() => handleCopy(token.value, token.name)}
                        style={{
                          padding: '6px',
                          borderRadius: '6px',
                          border: '1px solid #DADADA',
                          backgroundColor: copiedToken === token.name ? '#D7D0C5' : '#F9F6F0',
                          cursor: 'pointer',
                        }}
                      >
                        {copiedToken === token.name ? <Check size={14} color="#5E6458" /> : <Copy size={14} color="#1A1A1A" />}
                      </button>
                    </div>
                    <p style={{ fontFamily: token.value, fontSize: '24px', color: '#1A1A1A', marginBottom: '8px' }}>
                      The quick brown fox jumps over the lazy dog
                    </p>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Type Scale */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Type Scale (rem-based)
              </h3>
              <div className="space-y-2">
                {typographyTokens.sizes.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                            {token.name}
                          </code>
                          <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                            {token.value} ({token.px})
                          </span>
                        </div>
                        <p style={{ fontFamily: 'Inter, sans-serif', fontSize: token.value, color: '#1A1A1A', marginBottom: '4px' }}>
                          Sample Text
                        </p>
                        <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                          {token.usage}
                        </p>
                      </div>
                      <button
                        onClick={() => handleCopy(token.value, token.name)}
                        style={{
                          padding: '6px',
                          borderRadius: '6px',
                          border: '1px solid #DADADA',
                          backgroundColor: copiedToken === token.name ? '#D7D0C5' : '#F9F6F0',
                          cursor: 'pointer',
                        }}
                      >
                        {copiedToken === token.name ? <Check size={14} color="#5E6458" /> : <Copy size={14} color="#1A1A1A" />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Font Weights */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Font Weights
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {typographyTokens.weights.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                        {token.value}
                      </span>
                    </div>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', fontWeight: token.value, color: '#1A1A1A', marginBottom: '4px' }}>
                      Sample Text
                    </p>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Line Heights */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Line Heights
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {typographyTokens.lineHeights.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                        {token.value}
                      </span>
                    </div>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', lineHeight: token.value, color: '#1A1A1A', marginBottom: '4px' }}>
                      The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog.
                    </p>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Letter Spacing */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Letter Spacing
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {typographyTokens.letterSpacing.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                        {token.value}
                      </span>
                    </div>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', letterSpacing: token.value, color: '#1A1A1A', marginBottom: '4px' }}>
                      SAMPLE TEXT
                    </p>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Spacing Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Spacing Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              8px-based spacing scale (rem units) for consistent rhythm and Auto Layout principles.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {spacingTokens.map((token) => (
              <div 
                key={token.name}
                className="p-4 rounded-lg"
                style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
              >
                <div className="flex items-center justify-between mb-3">
                  <code style={{ fontFamily: 'monospace', fontSize: '13px', color: '#1A1A1A', fontWeight: '500' }}>
                    {token.name}
                  </code>
                  <span style={{ fontFamily: 'monospace', fontSize: '12px', color: '#8C8981' }}>
                    {token.value} ({token.px})
                  </span>
                </div>
                <div 
                  style={{ 
                    height: '32px',
                    backgroundColor: '#D7D0C5',
                    borderRadius: '4px',
                    marginBottom: '8px',
                    position: 'relative',
                  }}
                >
                  <div 
                    style={{ 
                      position: 'absolute',
                      left: '0',
                      top: '0',
                      bottom: '0',
                      width: token.px,
                      backgroundColor: '#5E6458',
                      borderRadius: '4px',
                    }}
                  />
                </div>
                <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                  {token.usage}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Sizing & Layout Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Sizing & Layout Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              Content widths, container padding, and grid gaps for consistent layout systems.
            </p>
          </div>

          <div className="space-y-6">
            {/* Content Widths */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Content Widths
              </h3>
              <div className="space-y-2">
                {layoutTokens.contentWidths.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '2px' }}>
                          {token.name}
                        </code>
                        <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                          {token.value} ({token.px})
                        </span>
                      </div>
                      <button
                        onClick={() => handleCopy(token.value, token.name)}
                        style={{
                          padding: '6px',
                          borderRadius: '6px',
                          border: '1px solid #DADADA',
                          backgroundColor: copiedToken === token.name ? '#D7D0C5' : '#F9F6F0',
                          cursor: 'pointer',
                        }}
                      >
                        {copiedToken === token.name ? <Check size={14} color="#5E6458" /> : <Copy size={14} color="#1A1A1A" />}
                      </button>
                    </div>
                    <div 
                      style={{ 
                        height: '40px',
                        maxWidth: token.value,
                        backgroundColor: '#D7D0C5',
                        borderRadius: '6px',
                        marginBottom: '8px',
                      }}
                    />
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Container Padding */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Container Padding
              </h3>
              <div className="grid md:grid-cols-3 gap-3">
                {layoutTokens.containerPadding.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
                      {token.name}
                    </code>
                    <div 
                      style={{ 
                        height: '48px',
                        backgroundColor: '#F9F6F0',
                        borderRadius: '6px',
                        padding: token.px,
                        marginBottom: '8px',
                      }}
                    >
                      <div style={{ height: '100%', backgroundColor: '#5E6458', borderRadius: '4px' }} />
                    </div>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6, marginBottom: '4px' }}>
                      {token.usage}
                    </p>
                    <span style={{ fontFamily: 'monospace', fontSize: '10px', color: '#8C8981' }}>
                      {token.value} ({token.px})
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Grid Gaps */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Grid Gaps
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {layoutTokens.gridGaps.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                        {token.value} ({token.px})
                      </span>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: token.px, marginBottom: '8px' }}>
                      <div style={{ height: '32px', backgroundColor: '#D7D0C5', borderRadius: '4px' }} />
                      <div style={{ height: '32px', backgroundColor: '#D7D0C5', borderRadius: '4px' }} />
                      <div style={{ height: '32px', backgroundColor: '#D7D0C5', borderRadius: '4px' }} />
                    </div>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Radius Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Radius Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              Border radius scale (rem-based) for component rounding.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {radiusTokens.map((token) => (
              <div 
                key={token.name}
                className="p-4 rounded-lg"
                style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
              >
                <div className="flex items-center justify-between mb-3">
                  <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                    {token.name}
                  </code>
                  <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                    {token.value}
                  </span>
                </div>
                <div 
                  style={{ 
                    width: '100%',
                    height: '64px',
                    backgroundColor: '#D7D0C5',
                    borderRadius: token.value,
                    marginBottom: '8px',
                  }}
                />
                <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                  {token.usage}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Border & Outline Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Border & Outline Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              Border widths, styles, and focus outlines for accessibility compliance.
            </p>
          </div>

          <div className="space-y-6">
            {/* Border Widths */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Border Widths
              </h3>
              <div className="grid md:grid-cols-4 gap-3">
                {borderTokens.widths.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '8px' }}>
                      {token.name}
                    </code>
                    <div 
                      style={{ 
                        height: '48px',
                        backgroundColor: '#F9F6F0',
                        borderRadius: '6px',
                        border: `${token.value} solid #1A1A1A`,
                        marginBottom: '8px',
                      }}
                    />
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6, marginBottom: '4px' }}>
                      {token.usage}
                    </p>
                    <span style={{ fontFamily: 'monospace', fontSize: '10px', color: '#8C8981' }}>
                      {token.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Border Styles */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Border Styles
              </h3>
              <div className="grid md:grid-cols-3 gap-3">
                {borderTokens.styles.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '8px' }}>
                      {token.name}
                    </code>
                    <div 
                      style={{ 
                        height: '48px',
                        backgroundColor: '#F9F6F0',
                        borderRadius: '6px',
                        border: token.value !== 'none' ? `2px ${token.value} #1A1A1A` : 'none',
                        marginBottom: '8px',
                      }}
                    />
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Focus Outlines */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Focus Outlines (ADA Compliant)
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {borderTokens.focus.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                        {token.value}
                      </span>
                    </div>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
              <div className="p-4 rounded-lg mt-3" style={{ backgroundColor: '#F9F6F0', border: '1px solid #DADADA' }}>
                <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#1A1A1A', lineHeight: '160%', opacity: 0.7 }}>
                  <strong>Example:</strong> <code style={{ fontFamily: 'monospace', fontSize: '11px' }}>outline: var(--outline-width-focus) var(--outline-style-focus) var(--outline-color-focus); outline-offset: var(--outline-offset-focus);</code>
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Elevation Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Elevation Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              Shadow system for depth and hierarchy.
            </p>
          </div>

          <div className="space-y-4">
            {elevationTokens.map((token) => (
              <div 
                key={token.name}
                className="p-6 rounded-lg"
                style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
              >
                <div className="flex items-start gap-6">
                  <div 
                    style={{ 
                      width: '120px',
                      height: '80px',
                      backgroundColor: '#F9F6F0',
                      borderRadius: '8px',
                      boxShadow: token.value,
                      flexShrink: 0,
                    }}
                  />
                  <div className="flex-1">
                    <code style={{ fontFamily: 'monospace', fontSize: '13px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '4px' }}>
                      {token.name}
                    </code>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#1A1A1A', opacity: 0.6, marginBottom: '6px' }}>
                      {token.usage}
                    </p>
                    <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                      {token.value}
                    </code>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Motion Tokens */}
        <section className="space-y-8">
          <div>
            <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '28px', color: '#1A1A1A', lineHeight: '120%', marginBottom: '8px' }}>
              Motion Tokens
            </h2>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '160%' }}>
              Duration, easing functions, and transition presets for animation consistency.
            </p>
          </div>

          <div className="space-y-6">
            {/* Duration */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Duration
              </h3>
              <div className="grid md:grid-cols-3 gap-3">
                {motionTokens.duration.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <code style={{ fontFamily: 'monospace', fontSize: '12px', color: '#1A1A1A', fontWeight: '500' }}>
                        {token.name}
                      </code>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#8C8981' }}>
                        {token.value}
                      </span>
                    </div>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '11px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Easing */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Easing Functions
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {motionTokens.easing.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
                      {token.name}
                    </code>
                    <code style={{ fontFamily: 'monospace', fontSize: '10px', color: '#8C8981', display: 'block', marginBottom: '6px' }}>
                      {token.value}
                    </code>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Transition Presets */}
            <div>
              <h3 style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', fontWeight: '600', marginBottom: '12px' }}>
                Transition Presets
              </h3>
              <div className="grid md:grid-cols-3 gap-3">
                {motionTokens.presets.map((token) => (
                  <div 
                    key={token.name}
                    className="p-4 rounded-lg"
                    style={{ backgroundColor: '#FFFFFF', border: '1px solid #DADADA' }}
                  >
                    <code style={{ fontFamily: 'monospace', fontSize: '11px', color: '#1A1A1A', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
                      {token.name}
                    </code>
                    <code style={{ fontFamily: 'monospace', fontSize: '10px', color: '#8C8981', display: 'block', marginBottom: '6px' }}>
                      {token.value}
                    </code>
                    <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '10px', color: '#1A1A1A', opacity: 0.6 }}>
                      {token.usage}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Export Footer */}
        <section className="p-8 rounded-2xl" style={{ backgroundColor: '#1A1A1A' }}>
          <h3 style={{ fontFamily: 'Garamond, serif', fontSize: '24px', color: '#F9F6F0', marginBottom: '12px' }}>
            Ready for Export
          </h3>
          <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#F9F6F0', lineHeight: '160%', opacity: 0.8, marginBottom: '16px' }}>
            This normalized token system is production-ready and can be exported directly as CSS variables, Shopify theme settings, or React/TypeScript constants. All tokens follow semantic naming conventions and are platform-agnostic.
          </p>
          <div className="flex gap-3">
            <div className="px-4 py-2 rounded-lg" style={{ backgroundColor: 'rgba(249, 246, 240, 0.1)', border: '1px solid rgba(249, 246, 240, 0.2)' }}>
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#F9F6F0', fontWeight: '600' }}>
                ✓ ADA/WCAG AAA Compliant
              </span>
            </div>
            <div className="px-4 py-2 rounded-lg" style={{ backgroundColor: 'rgba(249, 246, 240, 0.1)', border: '1px solid rgba(249, 246, 240, 0.2)' }}>
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#F9F6F0', fontWeight: '600' }}>
                ✓ Shopify Ready
              </span>
            </div>
            <div className="px-4 py-2 rounded-lg" style={{ backgroundColor: 'rgba(249, 246, 240, 0.1)', border: '1px solid rgba(249, 246, 240, 0.2)' }}>
              <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#F9F6F0', fontWeight: '600' }}>
                ✓ Platform Agnostic
              </span>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
