import { useState } from 'react';
import { 
  Search, 
  ShoppingCart, 
  Menu, 
  User, 
  ChevronDown,
  ChevronRight,
  X,
  Home,
  Heart,
  Package,
  Settings,
  Store,
  Sparkles
} from 'lucide-react';
import { 
  HOLYCircle, 
  HOLYDroplet,
  HOLYLeaf,
  HOLYSparkle,
  HOLYWand,
  HOLYGem,
  HOLYHeart,
  HOLYCompass
} from '../../components/icons/HOLYIcons';
import { TM, renderWithTM } from '../../components/core-system';

/**
 * ========================================
 * NAVIGATION PAGE  
 * HØLY | Ritual Care™ Design System
 * ========================================
 * 
 * Complete navigation system for Shopify theme.
 * Desktop/mobile navigation, mega menus, breadcrumbs, footer.
 * 
 * Engineering Handoff:
 * - Header as sections/header.liquid
 * - Mobile menu as separate snippet
 * - Mega menu data from link lists
 */

export default function NavigationPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [megaMenuOpen, setMegaMenuOpen] = useState(false);
  const [activeVariant, setActiveVariant] = useState<'dtc' | 'studio' | 'ritual' | 'checkout'>('dtc');

  // Ritual Systems data for mega menu
  const ritualSystems = [
    { 
      name: 'Ritual Aftercare™', 
      color: '#AAB5B2', 
      desc: 'Clinical meets ceremonial',
      icon: HOLYDroplet
    },
    { 
      name: 'Ritual Renewal™', 
      color: '#D9C4BB', 
      desc: 'Refined, luminous, alchemical',
      icon: HOLYSparkle
    },
    { 
      name: 'Ritual Touch™', 
      color: '#5E6458', 
      desc: 'Sensual, soft, connective',
      icon: HOLYHeart
    },
    { 
      name: 'Ritual Union™', 
      color: '#D9C4BB', 
      desc: 'Erotic, playful, healing',
      icon: HOLYGem
    },
    { 
      name: 'Ritual Vital™', 
      color: '#9C887A', 
      desc: 'Energized, primal, resilient',
      icon: HOLYLeaf
    }
  ];

  const breadcrumbExamples = [
    [
      { label: 'Home', href: '/' },
      { label: 'Shop', href: '/shop' },
      { label: 'Ritual Aftercare™', href: '/shop/aftercare' },
      { label: 'Daily Ritual Serum' }
    ],
    [
      { label: 'Home', href: '/' },
      { label: 'Ritual Finder', href: '/ritual-finder' },
      { label: 'Your Results' }
    ]
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F9F6F0' }}>
      <div className="max-w-7xl mx-auto p-8 space-y-20">
        
        {/* Page Header */}
        <div className="space-y-6">
          <div className="p-8 rounded-2xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #DADADA' }}>
            <div className="flex items-center gap-3 mb-3">
              <HOLYCompass size={32} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
              <h1 style={{ fontFamily: 'Garamond, serif', fontSize: '36px', fontWeight: '500', color: '#1A1A1A', lineHeight: '120%', margin: 0 }}>
                Navigation System
              </h1>
            </div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px', color: '#1A1A1A', lineHeight: '160%', opacity: 0.7, marginBottom: '16px' }}>
              The master reference for all navigation systems across HØLY | Ritual Care<TM /> touchpoints. Includes desktop header with Mega Menus, mobile navigation with bottom tabs, breadcrumb hierarchies, and specialized variants for DTC customers, Studio Partners, Ritual Finder, and Checkout flows.
            </p>
          </div>
        </div>

        {/* SECTION 1: DESKTOP NAVIGATION */}
        <div className="p-8 rounded-2xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #DADADA' }}>
          <div className="mb-8 pb-6" style={{ borderBottom: '1px solid #DADADA' }}>
            <div className="flex items-center gap-3 mb-2">
              <HOLYWand size={24} color="#1A1A1A" />
              <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '24px', fontWeight: '500', color: '#1A1A1A', lineHeight: '120%', margin: 0 }}>
                Desktop Navigation
              </h2>
            </div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '150%' }}>
              Full header with logo lockup, main menu items, Mega Menu flyouts, search, account, and cart with motion states.
            </p>
          </div>

          <div className="mb-6 flex gap-2">
            {[
              { key: 'dtc', label: 'DTC User' },
              { key: 'studio', label: 'Studio Pro' },
              { key: 'ritual', label: 'Ritual Finder' },
              { key: 'checkout', label: 'Checkout' }
            ].map(variant => (
              <button
                key={variant.key}
                onClick={() => setActiveVariant(variant.key as any)}
                className="px-4 py-2 rounded-lg transition-all"
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: '13px',
                  fontWeight: '500',
                  backgroundColor: activeVariant === variant.key ? '#1A1A1A' : 'transparent',
                  color: activeVariant === variant.key ? '#F9F6F0' : '#1A1A1A',
                  border: `2px solid ${activeVariant === variant.key ? '#1A1A1A' : '#DADADA'}`,
                  cursor: 'pointer'
                }}
              >
                {variant.label}
              </button>
            ))}
          </div>

          {/* Desktop Header - DTC Variant */}
          {activeVariant === 'dtc' && (
            <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #DADADA' }}>
              {/* Announcement Bar */}
              <div className="px-4 py-2 text-center" style={{ backgroundColor: '#9C887A' }}>
                <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#F9F6F0' }}>
                  Free shipping on orders over $75 · Studio Partners save 20%
                </p>
              </div>

              {/* Main Navigation */}
              <nav 
                className="px-8 py-4 flex items-center justify-between" 
                style={{ backgroundColor: '#FFFFFF', borderBottom: '2px solid #DADADA' }}
              >
                {/* Logo */}
                <a href="/" className="flex items-center gap-2">
                  <HOLYCircle size={28} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
                  <h1 style={{ 
                    fontFamily: 'Garamond, serif', 
                    fontSize: '24px', 
                    fontWeight: '500', 
                    color: '#1A1A1A',
                    transform: 'translateY(-2px)'
                  }}>
                    HØLY<TM />
                  </h1>
                </a>

                {/* Desktop Navigation Links */}
                <div className="flex items-center gap-6">
                  <div 
                    className="relative"
                    onMouseEnter={() => setMegaMenuOpen(true)}
                    onMouseLeave={() => setMegaMenuOpen(false)}
                  >
                    <button 
                      className="flex items-center gap-1 transition-colors group"
                      style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                    >
                      Shop
                      <ChevronDown className="w-4 h-4 transition-transform" style={{ 
                        transform: megaMenuOpen ? 'rotate(180deg)' : 'rotate(0deg)' 
                      }} />
                    </button>
                  </div>
                  <a 
                    href="/ritual-finder" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Ritual Finder
                  </a>
                  <a 
                    href="/our-story" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Our Story
                  </a>
                  <a 
                    href="/journal" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Journal
                  </a>
                  <a 
                    href="/studio-access" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Studio Access
                  </a>
                </div>

                {/* Action Icons */}
                <div className="flex items-center gap-4">
                  <button 
                    className="p-2 rounded-lg transition-colors hover:bg-[#F9F6F0]"
                    style={{ color: '#1A1A1A' }}
                  >
                    <Search className="w-5 h-5" />
                  </button>
                  <button 
                    className="p-2 rounded-lg transition-colors hover:bg-[#F9F6F0]"
                    style={{ color: '#1A1A1A' }}
                  >
                    <User className="w-5 h-5" />
                  </button>
                  <button 
                    className="p-2 rounded-lg transition-colors hover:bg-[#F9F6F0] relative"
                    style={{ color: '#1A1A1A' }}
                  >
                    <ShoppingCart className="w-5 h-5" />
                    <span 
                      className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center" 
                      style={{ 
                        backgroundColor: '#9C887A', 
                        fontSize: '11px', 
                        color: '#F9F6F0', 
                        fontWeight: '600',
                        fontFamily: 'Inter, sans-serif'
                      }}
                    >
                      3
                    </span>
                  </button>
                </div>
              </nav>
            </div>
          )}

          {/* Desktop Header - Studio Pro Variant */}
          {activeVariant === 'studio' && (
            <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #DADADA' }}>
              {/* Studio Pro Announcement Bar */}
              <div className="px-4 py-2 text-center" style={{ backgroundColor: '#5E6458' }}>
                <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#F9F6F0' }}>
                  Studio Partner Portal · 20% off all orders · Direct-to-studio fulfillment
                </p>
              </div>

              {/* Main Navigation */}
              <nav 
                className="px-8 py-4 flex items-center justify-between" 
                style={{ backgroundColor: '#FFFFFF', borderBottom: '2px solid #DADADA' }}
              >
                {/* Logo with Studio Badge */}
                <div className="flex items-center gap-3">
                  <a href="/" className="flex items-center gap-2">
                    <HOLYCircle size={28} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
                    <h1 style={{ 
                      fontFamily: 'Garamond, serif', 
                      fontSize: '24px', 
                      fontWeight: '500', 
                      color: '#1A1A1A',
                      transform: 'translateY(-2px)'
                    }}>
                      HØLY<TM />
                    </h1>
                  </a>
                  <div 
                    className="px-2 py-1 rounded-md"
                    style={{ 
                      backgroundColor: '#5E6458', 
                      fontFamily: 'Inter, sans-serif', 
                      fontSize: '11px',
                      fontWeight: '600',
                      color: '#F9F6F0',
                      letterSpacing: '0.5px'
                    }}
                  >
                    STUDIO PRO
                  </div>
                </div>

                {/* Studio Navigation Links */}
                <div className="flex items-center gap-6">
                  <a 
                    href="/shop" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Shop
                  </a>
                  <a 
                    href="/bulk-orders" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Bulk Orders
                  </a>
                  <a 
                    href="/studio-dashboard" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Dashboard
                  </a>
                  <a 
                    href="/resources" 
                    className="transition-colors"
                    style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                  >
                    Resources
                  </a>
                </div>

                {/* Action Icons */}
                <div className="flex items-center gap-4">
                  <button 
                    className="p-2 rounded-lg transition-colors hover:bg-[#F9F6F0]"
                    style={{ color: '#1A1A1A' }}
                  >
                    <Store className="w-5 h-5" />
                  </button>
                  <button 
                    className="p-2 rounded-lg transition-colors hover:bg-[#F9F6F0] relative"
                    style={{ color: '#1A1A1A' }}
                  >
                    <ShoppingCart className="w-5 h-5" />
                  </button>
                  <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ backgroundColor: '#F9F6F0' }}>
                    <User className="w-4 h-4" style={{ color: '#1A1A1A' }} />
                    <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#1A1A1A' }}>
                      Studio Name
                    </span>
                  </div>
                </div>
              </nav>
            </div>
          )}

          {/* Desktop Header - Ritual Finder Variant */}
          {activeVariant === 'ritual' && (
            <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #DADADA' }}>
              <nav 
                className="px-8 py-4 flex items-center justify-between" 
                style={{ backgroundColor: '#FFFFFF', borderBottom: '2px solid #DADADA' }}
              >
                {/* Logo */}
                <a href="/" className="flex items-center gap-2">
                  <HOLYCircle size={28} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
                  <h1 style={{ 
                    fontFamily: 'Garamond, serif', 
                    fontSize: '24px', 
                    fontWeight: '500', 
                    color: '#1A1A1A',
                    transform: 'translateY(-2px)'
                  }}>
                    HØLY<TM />
                  </h1>
                </a>

                {/* Ritual Finder Title */}
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" style={{ color: '#9C887A' }} />
                  <span style={{ 
                    fontFamily: 'Garamond, serif', 
                    fontSize: '18px', 
                    color: '#1A1A1A',
                    fontWeight: '500'
                  }}>
                    Ritual Finder
                  </span>
                </div>

                {/* Minimal Actions */}
                <div className="flex items-center gap-4">
                  <button 
                    className="p-2 rounded-lg transition-colors hover:bg-[#F9F6F0]"
                    style={{ color: '#1A1A1A' }}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </nav>
            </div>
          )}

          {/* Desktop Header - Checkout Variant */}
          {activeVariant === 'checkout' && (
            <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #DADADA' }}>
              <nav 
                className="px-8 py-4 flex items-center justify-between" 
                style={{ backgroundColor: '#FFFFFF', borderBottom: '2px solid #DADADA' }}
              >
                {/* Logo */}
                <a href="/" className="flex items-center gap-2">
                  <HOLYCircle size={28} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
                  <h1 style={{ 
                    fontFamily: 'Garamond, serif', 
                    fontSize: '24px', 
                    fontWeight: '500', 
                    color: '#1A1A1A',
                    transform: 'translateY(-2px)'
                  }}>
                    HØLY<TM />
                  </h1>
                </a>

                {/* Checkout Progress */}
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#1A1A1A' }} />
                    <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#1A1A1A' }}>Cart</span>
                  </div>
                  <ChevronRight className="w-4 h-4" style={{ color: '#1A1A1A', opacity: 0.3 }} />
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#1A1A1A' }} />
                    <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#1A1A1A' }}>Information</span>
                  </div>
                  <ChevronRight className="w-4 h-4" style={{ color: '#1A1A1A', opacity: 0.3 }} />
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#1A1A1A', opacity: 0.3 }} />
                    <span style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#1A1A1A', opacity: 0.3 }}>Payment</span>
                  </div>
                </div>

                {/* Help */}
                <a 
                  href="/help" 
                  className="transition-colors"
                  style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A' }}
                >
                  Need Help?
                </a>
              </nav>
            </div>
          )}
        </div>

        {/* SECTION 2: MEGA MENU SYSTEM */}
        <div className="p-8 rounded-2xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #DADADA' }}>
          <div className="mb-8 pb-6" style={{ borderBottom: '1px solid #DADADA' }}>
            <div className="flex items-center gap-3 mb-2">
              <HOLYGem size={24} color="#1A1A1A" />
              <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '24px', fontWeight: '500', color: '#1A1A1A', lineHeight: '120%', margin: 0 }}>
                Mega Menu System
              </h2>
            </div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '150%' }}>
              Rich dropdown navigation showcasing Ritual Systems with color indicators, descriptions, and category shortcuts.
            </p>
          </div>

          <div>
            <div className="grid grid-cols-2 gap-12">
              {/* Ritual Systems Column */}
              <div>
                <p style={{ 
                  fontFamily: 'Inter, sans-serif', 
                  fontSize: '12px', 
                  color: '#1A1A1A', 
                  fontWeight: '600',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                  marginBottom: '16px'
                }}>
                  Ritual Systems
                </p>
                <div className="space-y-3">
                  {ritualSystems.map((system, index) => {
                    const IconComponent = system.icon;
                    return (
                      <button
                        key={index}
                        className="w-full flex items-center gap-3 p-3 rounded-lg transition-all hover:bg-[#F9F6F0]"
                        style={{ cursor: 'pointer' }}
                      >
                        <div 
                          className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: system.color }}
                        >
                          <IconComponent size={20} color="#FFFFFF" opacity={1} />
                        </div>
                        <div className="text-left flex-1">
                          <p style={{ fontFamily: 'Garamond, serif', fontSize: '16px', color: '#1A1A1A', marginBottom: '2px' }}>
                            {renderWithTM(system.name)}
                          </p>
                          <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#1A1A1A', opacity: 0.6 }}>
                            {system.desc}
                          </p>
                        </div>
                        <ChevronRight className="w-4 h-4 flex-shrink-0" style={{ color: '#1A1A1A', opacity: 0.3 }} />
                      </button>
                    );
                  })}
                </div>
              </div>
              
              {/* Shop by Category Column */}
              <div>
                <p style={{ 
                  fontFamily: 'Inter, sans-serif', 
                  fontSize: '12px', 
                  color: '#1A1A1A', 
                  fontWeight: '600',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                  marginBottom: '16px'
                }}>
                  Shop by Category
                </p>
                <div className="space-y-2">
                  {['Shop All', 'New Arrivals', 'Sets & Kits', 'Studio Exclusive', 'Sale'].map((category, index) => (
                    <button
                      key={index}
                      className="w-full text-left px-3 py-2 rounded-lg transition-all hover:bg-[#F9F6F0]"
                      style={{
                        fontFamily: 'Inter, sans-serif',
                        fontSize: '14px',
                        color: '#1A1A1A',
                        cursor: 'pointer'
                      }}
                    >
                      {category}
                    </button>
                  ))}
                </div>
                
                {/* Featured CTA Card */}
                <div className="mt-8 p-4 rounded-xl" style={{ backgroundColor: '#D9C4BB' }}>
                  <p style={{ fontFamily: 'Garamond, serif', fontSize: '16px', color: '#1A1A1A', marginBottom: '8px' }}>
                    Studio Membership
                  </p>
                  <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#1A1A1A', opacity: 0.8, marginBottom: '12px', lineHeight: '140%' }}>
                    Direct-to-studio Ritual Care<TM /> for elevated piercing and tattoo aftercare.
                  </p>
                  <button
                    className="px-4 py-2 rounded-lg"
                    style={{
                      fontFamily: 'Inter, sans-serif',
                      fontSize: '13px',
                      fontWeight: '500',
                      color: '#F9F6F0',
                      backgroundColor: '#1A1A1A',
                      border: 'none',
                      cursor: 'pointer'
                    }}
                  >
                    Learn More
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 3: MOBILE NAVIGATION */}
        <div className="p-8 rounded-2xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #DADADA' }}>
          <div className="mb-8 pb-6" style={{ borderBottom: '1px solid #DADADA' }}>
            <div className="flex items-center gap-3 mb-2">
              <HOLYCircle size={24} color="#1A1A1A" />
              <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '24px', fontWeight: '500', color: '#1A1A1A', lineHeight: '120%', margin: 0 }}>
                Mobile Navigation
              </h2>
            </div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '150%' }}>
              Mobile-first navigation with slide-out drawer and sticky bottom tab bar. All touch targets meet 48px minimum.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Mobile Header */}
            <div>
              <h3 style={{ 
                fontFamily: 'Inter, sans-serif', 
                fontSize: '16px', 
                color: '#1A1A1A', 
                fontWeight: '600',
                marginBottom: '12px'
              }}>
                Mobile Header
              </h3>
              <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #DADADA', maxWidth: '375px' }}>
                <nav 
                  className="px-4 py-3 flex items-center justify-between" 
                  style={{ backgroundColor: '#FFFFFF', borderBottom: '2px solid #DADADA' }}
                >
                  <button 
                    className="p-2 rounded-lg transition-colors active:bg-[#F9F6F0]"
                    style={{ color: '#1A1A1A' }}
                  >
                    <Menu className="w-6 h-6" />
                  </button>
                  
                  <a href="/" className="flex items-center gap-2">
                    <HOLYCircle size={24} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
                    <h1 style={{ 
                      fontFamily: 'Garamond, serif', 
                      fontSize: '20px', 
                      fontWeight: '500', 
                      color: '#1A1A1A',
                      transform: 'translateY(-1px)'
                    }}>
                      HØLY<TM />
                    </h1>
                  </a>

                  <button 
                    className="p-2 rounded-lg transition-colors active:bg-[#F9F6F0] relative"
                    style={{ color: '#1A1A1A' }}
                  >
                    <ShoppingCart className="w-6 h-6" />
                    <span 
                      className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center" 
                      style={{ 
                        backgroundColor: '#9C887A', 
                        fontSize: '11px', 
                        color: '#F9F6F0', 
                        fontWeight: '600',
                        fontFamily: 'Inter, sans-serif'
                      }}
                    >
                      3
                    </span>
                  </button>
                </nav>
              </div>
            </div>

            {/* Mobile Drawer Menu */}
            <div>
              <h3 style={{ 
                fontFamily: 'Inter, sans-serif', 
                fontSize: '16px', 
                color: '#1A1A1A', 
                fontWeight: '600',
                marginBottom: '12px'
              }}>
                Mobile Drawer Menu
              </h3>
              <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #DADADA', maxWidth: '375px' }}>
                <div className="p-6" style={{ backgroundColor: '#FFFFFF' }}>
                  {/* Drawer Header */}
                  <div className="flex items-center justify-between mb-6 pb-4" style={{ borderBottom: '1px solid #DADADA' }}>
                    <div className="flex items-center gap-2">
                      <HOLYCircle size={24} color="#1A1A1A" opacity={0.8} strokeWidth={1.5} />
                      <h1 style={{ 
                        fontFamily: 'Garamond, serif', 
                        fontSize: '20px', 
                        fontWeight: '500', 
                        color: '#1A1A1A',
                        transform: 'translateY(-1px)'
                      }}>
                        HØLY<TM />
                      </h1>
                    </div>
                    <button 
                      className="p-2 rounded-lg transition-colors active:bg-[#F9F6F0]"
                      style={{ color: '#1A1A1A' }}
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>

                  {/* Menu Items */}
                  <div className="space-y-1">
                    {['Shop', 'Ritual Finder', 'Our Story', 'Journal', 'Studio Access'].map((item, index) => (
                      <a
                        key={index}
                        href="#"
                        className="flex items-center justify-between py-3 px-3 rounded-lg transition-colors active:bg-[#F9F6F0]"
                        style={{ 
                          fontFamily: 'Inter, sans-serif',
                          fontSize: '16px',
                          color: '#1A1A1A',
                          textDecoration: 'none'
                        }}
                      >
                        {item}
                        <ChevronRight className="w-5 h-5" style={{ color: '#1A1A1A', opacity: 0.3 }} />
                      </a>
                    ))}
                  </div>

                  {/* User Actions */}
                  <div className="mt-6 pt-6 space-y-2" style={{ borderTop: '1px solid #DADADA' }}>
                    <button
                      className="w-full flex items-center gap-3 py-3 px-3 rounded-lg transition-colors active:bg-[#F9F6F0]"
                      style={{ 
                        fontFamily: 'Inter, sans-serif',
                        fontSize: '14px',
                        color: '#1A1A1A'
                      }}
                    >
                      <User className="w-5 h-5" />
                      Account
                    </button>
                    <button
                      className="w-full flex items-center gap-3 py-3 px-3 rounded-lg transition-colors active:bg-[#F9F6F0]"
                      style={{ 
                        fontFamily: 'Inter, sans-serif',
                        fontSize: '14px',
                        color: '#1A1A1A'
                      }}
                    >
                      <Search className="w-5 h-5" />
                      Search
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Bottom Navigation */}
          <div className="mt-8">
            <h3 style={{ 
              fontFamily: 'Inter, sans-serif', 
              fontSize: '16px', 
              color: '#1A1A1A', 
              fontWeight: '600',
              marginBottom: '12px'
            }}>
              Bottom Tab Bar (Optional)
            </h3>
            <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #DADADA', maxWidth: '375px' }}>
              <div 
                className="px-4 py-3 flex items-center justify-around" 
                style={{ backgroundColor: '#FFFFFF', borderTop: '1px solid #DADADA' }}
              >
                {[
                  { icon: Home, label: 'Home' },
                  { icon: Search, label: 'Search' },
                  { icon: Heart, label: 'Saved' },
                  { icon: Package, label: 'Orders' },
                  { icon: Settings, label: 'Settings' }
                ].map((tab, index) => (
                  <button
                    key={index}
                    className="flex flex-col items-center gap-1 p-2"
                    style={{ 
                      color: index === 0 ? '#1A1A1A' : '#8C8981',
                      opacity: index === 0 ? 1 : 0.6
                    }}
                  >
                    <tab.icon className="w-6 h-6" />
                    <span style={{ 
                      fontFamily: 'Inter, sans-serif',
                      fontSize: '11px'
                    }}>
                      {tab.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 4: BREADCRUMBS */}
        <div className="p-8 rounded-2xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #DADADA' }}>
          <div className="mb-8 pb-6" style={{ borderBottom: '1px solid #DADADA' }}>
            <div className="flex items-center gap-3 mb-2">
              <HOLYCompass size={24} color="#1A1A1A" />
              <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '24px', fontWeight: '500', color: '#1A1A1A', lineHeight: '120%', margin: 0 }}>
                Breadcrumbs
              </h2>
            </div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '150%' }}>
              Hierarchical navigation for product and collection pages.
            </p>
          </div>

          <div className="space-y-6">
            {breadcrumbExamples.map((breadcrumb, idx) => (
              <div key={idx}>
                <div className="flex items-center gap-2">
                  {breadcrumb.map((crumb, index) => (
                    <div key={index} className="flex items-center gap-2">
                      {crumb.href ? (
                        <a 
                          href={crumb.href}
                          style={{ 
                            fontFamily: 'Inter, sans-serif',
                            fontSize: '13px',
                            color: '#1A1A1A',
                            opacity: 0.6,
                            textDecoration: 'none'
                          }}
                        >
                          {crumb.label}
                        </a>
                      ) : (
                        <span style={{ 
                          fontFamily: 'Inter, sans-serif',
                          fontSize: '13px',
                          color: '#1A1A1A',
                          fontWeight: '500'
                        }}>
                          {crumb.label}
                        </span>
                      )}
                      {index < breadcrumb.length - 1 && (
                        <ChevronRight className="w-4 h-4" style={{ color: '#1A1A1A', opacity: 0.3 }} />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SECTION 5: FOOTER */}
        <div className="p-8 rounded-2xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #DADADA' }}>
          <div className="mb-8 pb-6" style={{ borderBottom: '1px solid #DADADA' }}>
            <div className="flex items-center gap-3 mb-2">
              <HOLYCompass size={24} color="#1A1A1A" />
              <h2 style={{ fontFamily: 'Garamond, serif', fontSize: '24px', fontWeight: '500', color: '#1A1A1A', lineHeight: '120%', margin: 0 }}>
                Footer
              </h2>
            </div>
            <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '14px', color: '#1A1A1A', opacity: 0.7, lineHeight: '150%' }}>
              4-column footer with navigation, newsletter, and social links.
            </p>
          </div>

          <div className="rounded-2xl overflow-hidden" style={{ border: '2px solid #1A1A1A' }}>
            <footer className="p-12" style={{ backgroundColor: '#1A1A1A' }}>
              <div className="grid md:grid-cols-4 gap-8 mb-12">
                {[
                  {
                    title: 'Shop',
                    links: ['All Rituals', 'New Arrivals', 'Best Sellers', 'Studio Exclusive']
                  },
                  {
                    title: 'Philosophy',
                    links: ['Our Story', 'Sacred Self-Care', 'Botanical Purity', 'Sustainability']
                  },
                  {
                    title: 'Support',
                    links: ['Contact', 'FAQ', 'Shipping', 'Returns']
                  },
                  {
                    title: 'Connect',
                    links: ['Instagram', 'TikTok', 'Newsletter', 'Ritual Finder']
                  }
                ].map((column, index) => (
                  <div key={index}>
                    <p style={{ 
                      fontFamily: 'Inter, sans-serif', 
                      fontSize: '12px', 
                      color: '#D7D0C5', 
                      fontWeight: '600',
                      textTransform: 'uppercase',
                      letterSpacing: '0.1em',
                      marginBottom: '12px'
                    }}>
                      {column.title}
                    </p>
                    <div className="space-y-2">
                      {column.links.map((link, idx) => (
                        <a
                          key={idx}
                          href="#"
                          style={{ 
                            display: 'block',
                            fontFamily: 'Inter, sans-serif',
                            fontSize: '13px',
                            color: '#F9F6F0',
                            opacity: 0.7,
                            textDecoration: 'none'
                          }}
                        >
                          {link}
                        </a>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-8" style={{ borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                <p style={{ 
                  fontFamily: 'Inter, sans-serif',
                  fontSize: '11px',
                  color: '#F9F6F0',
                  opacity: 0.5,
                  textAlign: 'center'
                }}>
                  © 2026 HØLY | Ritual Care<TM />. All rights reserved.
                </p>
              </div>
            </footer>
          </div>
        </div>

        {/* Engineering Notes */}
        <div className="p-8 rounded-2xl" style={{ backgroundColor: '#1A1A1A', border: '2px solid #1A1A1A' }}>
          <h3 style={{ 
            fontFamily: 'Garamond, serif',
            fontSize: '20px',
            color: '#D7D0C5',
            marginBottom: '16px'
          }}>
            Engineering Handoff Notes
          </h3>
          <div className="space-y-4">
            <div>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#D7D0C5', fontWeight: '600', marginBottom: '4px' }}>
                Sticky Header
              </p>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#F9F6F0', lineHeight: '160%', opacity: 0.8 }}>
                Header should be sticky on scroll with smooth transition. Add .header-sticky class when scrolled {'>'} 100px. Use CSS position: sticky for performance.
              </p>
            </div>

            <div>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#D7D0C5', fontWeight: '600', marginBottom: '4px' }}>
                Mobile Breakpoint
              </p>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#F9F6F0', lineHeight: '160%', opacity: 0.8 }}>
                Switch to mobile navigation at 768px. Hide desktop nav, show hamburger menu. Mobile drawer should slide in from left with backdrop overlay.
              </p>
            </div>

            <div>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#D7D0C5', fontWeight: '600', marginBottom: '4px' }}>
                Link Lists (Shopify)
              </p>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#F9F6F0', lineHeight: '160%', opacity: 0.8 }}>
                Navigation is driven by Shopify link lists (linklists). Create main-menu, rituals, footer-1, footer-2, etc. in Shopify Admin → Navigation.
              </p>
            </div>

            <div>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#D7D0C5', fontWeight: '600', marginBottom: '4px' }}>
                Accessibility
              </p>
              <p style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px', color: '#F9F6F0', lineHeight: '160%', opacity: 0.8 }}>
                Use semantic HTML ({'<nav>, <ul>, <li>'}). Add aria-labels to navigation regions. Ensure keyboard navigation works (Tab, Enter). Mobile menu should trap focus.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
